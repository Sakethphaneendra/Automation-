const KEY = "auxTrackerState";
let state = null;

const $ = id => document.getElementById(id);

function fmt(ms) {
  ms = Math.max(0, Math.floor(ms || 0));
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return [h, m, sec].map((v, i) => i === 0 ? String(v).padStart(2, "0") : String(v).padStart(2, "0")).join(":");
}
function kind(status) {
  const s = String(status || "").toLowerCase().trim();
  if (s === "offline" || s.includes("offline")) return "offline";
  if (s === "break" || s.includes("on break") || s.startsWith("break")) return "break";
  if (s === "lunch" || s.includes("lunch")) return "lunch";
  if (["available", "meeting", "training", "coaching"].includes(s)) return "login";
  return "other";
}
function totals(now) {
  const all = [...(state?.history || [])];
  if (state?.running && state.currentStatus && state.statusStartedAt) {
    all.push({ status: state.currentStatus, startedAt: state.statusStartedAt, endedAt: now, durationMs: Math.max(0, now - state.statusStartedAt) });
  }
  const out = { login: 0, break: 0, lunch: 0, floor: 0 };
  for (const x of all) {
    const k = kind(x.status);
    if (k === "offline") continue;
    out.floor += x.durationMs || 0;
    if (k === "login") out.login += x.durationMs || 0;
    if (k === "break") out.break += x.durationMs || 0;
    if (k === "lunch") out.lunch += x.durationMs || 0;
  }
  return out;
}
function render() {
  if (!state) return;
  const now = Date.now();
  const t = totals(now);
  $("currentStatus").textContent = state.currentStatus || (state.running ? "Waiting for AUX…" : "Not tracking");
  $("activeTimer").textContent = state.running && state.statusStartedAt ? fmt(now - state.statusStartedAt) : "00:00:00";
  $("trackingState").textContent = state.running ? "● Tracking is active" :
    (state.lastStoppedReason === "offline" ? "Tracker stopped automatically at Offline" :
      state.lastStoppedReason === "target-tab-closed" ? "Target website tab closed • saved data preserved" :
        "Tracking is not active");
  $("loginTimer").textContent = fmt(t.login);
  $("breakTimer").textContent = fmt(t.break);
  $("lunchTimer").textContent = fmt(t.lunch);
  $("floorTimer").textContent = fmt(t.floor);

  const breakOver = Math.max(0, t.break - 30 * 60 * 1000);
  const lunchOver = Math.max(0, t.lunch - 30 * 60 * 1000);
  $("breakNote").textContent = breakOver ? `Exceeded by ${fmt(breakOver)}` : `30 min allowance • ${fmt(30 * 60 * 1000 - t.break)} remaining`;
  $("lunchNote").textContent = lunchOver ? `Exceeded by ${fmt(lunchOver)}` : `30 min allowance • ${fmt(30 * 60 * 1000 - t.lunch)} remaining`;
  $("breakNote").classList.toggle("exceeded", !!breakOver);
  $("lunchNote").classList.toggle("exceeded", !!lunchOver);
}
async function load() {
  const r = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  state = r.state;
  render();
}
function updateClock() {
  const now = new Date();

  $("clock").textContent = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  }).format(now);

  $("date").textContent = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(now);
}
$("clear").addEventListener("click", async () => {
  if (!confirm("Clear all saved AUX history and timer totals?")) return;
  await chrome.runtime.sendMessage({ type: "CLEAR_HISTORY" });
  await load();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[KEY]) { state = changes[KEY].newValue; render(); }
});
setInterval(() => { updateClock(); render(); }, 1000);
updateClock(); load();
