(() => {
  if (window.__auxTrackerInstalled) return;
  window.__auxTrackerInstalled = true;

  let running = false;
  let pollTimer = null;
  let observer = null;
  let watchedElement = null;
  let lastStatus = "";

  function getStatusElement() {
    return document.querySelector(".agentStatusControls");
  }

  function readStatus(el) {
    if (!el) return "";
    if (el.tagName === "SELECT") {
      const option = el.options?.[el.selectedIndex];
      return String(option?.textContent || option?.value || "").replace(/\s+/g, " ").trim();
    }
    const selected = el.querySelector("option:checked,[aria-selected='true'],[selected]");
    return String(selected?.textContent || selected?.getAttribute?.("value") || el.value || el.textContent || "")
      .replace(/\s+/g, " ").trim();
  }

  function sendStatus(status) {
    if (!running || !status) return;
    if (status === lastStatus) return;
    lastStatus = status;
    chrome.runtime.sendMessage({ type: "STATUS_UPDATE", status }).catch(() => {});
  }

  function attach(el) {
    if (!el || el === watchedElement) return;
    watchedElement = el;
    el.addEventListener("change", () => sendStatus(readStatus(el)), true);
    sendStatus(readStatus(el));
  }

  function tick() {
    if (!running) return;
    const el = getStatusElement();
    if (el !== watchedElement) attach(el);
    if (el) sendStatus(readStatus(el));
  }

  function start() {
    running = true;
    if (!pollTimer) pollTimer = setInterval(tick, 250);
    if (!observer) {
      observer = new MutationObserver(() => tick());
      observer.observe(document.documentElement || document, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["value", "selected", "class", "aria-selected"]
      });
    }
    tick();
  }

  function stop() {
    running = false;
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
    if (observer) observer.disconnect();
    observer = null;
    watchedElement = null;
    lastStatus = "";
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "START_MONITORING") start();
    if (message?.type === "STOP_MONITORING") stop();
  });

  chrome.runtime.sendMessage({ type: "GET_STATE" }).then((res) => {
    if (res?.state?.running && res.state.targetTabId != null) start();
  }).catch(() => {});
})();
