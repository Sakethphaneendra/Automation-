(() => {
  if (window.__auxTrackerStatusMonitorInstalled) return;
  window.__auxTrackerStatusMonitorInstalled = true;

  let running = false;
  let pollTimer = null;
  let statusObserver = null;
  let watchedSelect = null;
  let lastStatus = "";

  /*
   * Lowe's renders:
   * <div class="agentStatusControls"> ... <select class="select"> ... </select>
   *
   * The old build watched the container itself. React can replace the
   * <select> without changing the container, and a controlled React select
   * does not reliably expose its selected state through container text.
   * Always locate the actual SELECT and read its .value/selectedOptions.
   */

  function getStatusSelect() {
    const container = document.querySelector(".agentStatusControls");
    if (!container) return null;

    // Primary selector used by the supplied Lowe's DOM.
    const select = container.querySelector("select.select, select");
    if (select) return select;

    return null;
  }

  function readStatus(select) {
    if (!select) return "";

    // Native SELECT is the source of truth for a React controlled select.
    const value = String(select.value ?? "").trim();
    const option =
      select.selectedOptions?.[0] ||
      select.options?.[select.selectedIndex];

    const label = String(option?.textContent || "").replace(/\s+/g, " ").trim();

    // Ignore the placeholder. It is not an AUX state.
    if (!value || value.toLowerCase() === "select status") return "";

    // Prefer the visible label because dashboard/history should show
    // "On Break", "Available - Case", "System Issue", etc.
    return label || value;
  }

  function sendStatus(status) {
    if (!running || !status || status === lastStatus) return;
    lastStatus = status;

    chrome.runtime.sendMessage({
      type: "STATUS_UPDATE",
      status
    }).catch(() => {});
  }

  function attach(select) {
    if (!select || select === watchedSelect) return;

    if (watchedSelect) {
      try {
        watchedSelect.removeEventListener("change", onStatusChange, true);
      } catch (_) {}
    }

    watchedSelect = select;
    select.addEventListener("change", onStatusChange, true);

    // Read immediately in case the agent was already in an AUX state
    // before the extension started.
    sendStatus(readStatus(select));
  }

  function onStatusChange(event) {
    const select = event.currentTarget || watchedSelect;
    sendStatus(readStatus(select));
  }

  function tick() {
    if (!running) return;

    const select = getStatusSelect();

    // React may destroy/recreate the SELECT while keeping
    // .agentStatusControls. Re-attach whenever its identity changes.
    if (select !== watchedSelect) {
      attach(select);
    }

    if (select) {
      sendStatus(readStatus(select));
    }
  }

  function start() {
    if (running) {
      tick();
      return;
    }

    running = true;

    // Polling is deliberately kept because React can change the native
    // select's .value without producing an attribute mutation.
    if (!pollTimer) {
      pollTimer = setInterval(tick, 250);
    }

    if (!statusObserver) {
      statusObserver = new MutationObserver(() => tick());

      statusObserver.observe(document.documentElement || document, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: [
          "value",
          "selected",
          "aria-selected",
          "class"
        ]
      });
    }

    tick();
  }

  function stop() {
    running = false;

    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;

    if (statusObserver) statusObserver.disconnect();
    statusObserver = null;

    if (watchedSelect) {
      try {
        watchedSelect.removeEventListener("change", onStatusChange, true);
      } catch (_) {}
    }

    watchedSelect = null;
    lastStatus = "";
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "START_MONITORING") start();
    if (message?.type === "STOP_MONITORING") stop();
  });

  // Recover when the content script was loaded before START was pressed.
  chrome.runtime.sendMessage({ type: "GET_STATE" })
    .then((res) => {
      if (res?.state?.running && res.state.targetTabId != null) {
        start();
      }
    })
    .catch(() => {});
})();

function normalizeText(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

/* =========================
   AUX ADD-ON OBSERVERS
   Passive integration only:
   - no preventDefault()
   - no stopPropagation()
   - no stopImmediatePropagation()
   - no replacement of Lowe's native controls
   - observe native state/results only
========================= */

injectAuxStyles();

function injectAuxStyles() {
  if (document.getElementById("aux-tracker-target-style")) return;
  const link = document.createElement("link");
  link.id = "aux-tracker-target-style";
  link.rel = "stylesheet";
  link.href = chrome.runtime.getURL("target-overlays.css");
  (document.head || document.documentElement).appendChild(link);
}

{
  const ADDON_KEY = "auxTrackerAddons";

  const DEFAULT_ADDONS = {
    chatAlerts: false,
    chatInterval: 15,
    pulseTracker: false,
    asat: 0,
    dsat: 0,
    totalChats: 0
  };

  let isTargetTab = false;
  let addonSettings = { ...DEFAULT_ADDONS };

  // Waiting-chat state.
  const queueEntries = new Map();
  const pendingAccepts = new Map();
  let activeAlertKey = "";
  const QUEUE_ABSENCE_GRACE_MS = 5000;

  // Pulse/end-chat state.
  let agentEndState = null;
  let endChatPopup = null;
  const pulseShownForChats = new Set();

  let appObserver = null;
  let queueScanTimer = null;

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "TARGET_TAB_STATE") return;

    const next = !!message.isTargetTab;
    if (next === isTargetTab) return;

    isTargetTab = next;

    if (isTargetTab) {
      startAppObserver();
      if (addonSettings.chatAlerts) scanChatQueue();
    } else {
      stopAppObserver();
    }
  });

  function requestTargetTabState() {
    chrome.runtime.sendMessage({ type: "IS_TARGET_TAB" })
      .then(res => {
        const next = !!res?.isTargetTab;
        if (next === isTargetTab) return;

        isTargetTab = next;
        if (isTargetTab) {
          startAppObserver();
          if (addonSettings.chatAlerts) scanChatQueue();
        } else {
          stopAppObserver();
        }
      })
      .catch(() => {});
  }

  function getAlertSeconds() {
    return Math.max(5, Math.min(30, Number(addonSettings.chatInterval) || 15));
  }

  function readAttributeIdentity(root) {
    if (!root) return "";

    const attrs = [
      "data-chat-id",
      "data-session-id",
      "data-request-id",
      "data-conversation-id",
      "data-interaction-id",
      "data-customer-id",
      "data-contact-id",
      "data-chatid",
      "data-sessionid",
      "data-requestid",
      "data-conversationid",
      "data-interactionid"
    ];

    const nodes = [root, ...root.querySelectorAll("*")];

    for (const node of nodes) {
      for (const attr of attrs) {
        const value = normalizeText(node.getAttribute?.(attr));
        if (value) return `${attr}:${value}`;
      }
    }

    return "";
  }

  function getHeader() {
    return document.querySelector(".chatHeader");
  }

  function getCurrentChatIdentity(header = getHeader()) {
    if (!header) return "";

    const strongId = readAttributeIdentity(header);
    if (strongId) return strongId;

    const name = normalizeText(header.querySelector(".name")?.textContent);
    const sub = normalizeText(header.querySelector(".sub")?.textContent);

    return [name, sub].filter(Boolean).join("|");
  }

  function getQueueIdentity(item) {
    if (!item) return "";

    const strongId = readAttributeIdentity(item);
    if (strongId) return strongId;

    const values = [];
    const name = normalizeText(item.querySelector(".queueLeft .name")?.textContent);

    if (name) values.push(`name:${name}`);

    for (const sub of item.querySelectorAll(".queueLeft .sub")) {
      const text = normalizeText(sub.textContent);
      if (!text) continue;
      if (/^waiting\s+for\s+\d+\s*s?$/i.test(text)) continue;
      values.push(`sub:${text}`);
    }

    return values.join("|") || "";
  }

  function getWaitingSeconds(item) {
    const text = normalizeText(item?.textContent);
    const match = text.match(/waiting\s+for\s+(\d+)\s*s?/i);
    return match ? Number(match[1]) : 0;
  }

  function getButtonLabel(button) {
    if (!button) return "";

    return normalizeText(
      button.getAttribute("aria-label") ||
      button.getAttribute("title") ||
      button.textContent
    ).toLowerCase();
  }

  function isAcceptButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;

    const label = getButtonLabel(button);
    return label === "accept" || label.includes("accept");
  }

  function isEndChatButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;

    return getButtonLabel(button) === "end chat";
  }

  function isCloseChatButton(target) {
    const button = target?.closest?.("button");
    const header = getHeader();

    if (!button || !header || !header.contains(button)) return false;

    const label = getButtonLabel(button);

    // Lowe's native post-End-Chat control is commonly labelled "Close".
    // Keep this scoped to .chatHeader so unrelated page buttons cannot trigger it.
    return label === "close" ||
      label === "close chat" ||
      label === "close conversation";
  }

  function queueHasAccept(item) {
    return [...item.querySelectorAll("button")].some(button => {
      const label = getButtonLabel(button);
      return label === "accept" || label.includes("accept");
    });
  }

  function findQueueItemByIdentity(key) {
    return [...document.querySelectorAll(".queueList .queueItem")]
      .find(item => getQueueIdentity(item) === key) || null;
  }

  function clearQueueEntryTimer(entry) {
    if (entry?.timer) {
      clearTimeout(entry.timer);
      entry.timer = null;
    }
  }

  function removeChatWaitingPopup() {
    document.getElementById("aux-chat-alert")?.remove();
    activeAlertKey = "";
  }

  function showChatWaitingPopup(entryKey) {
    if (!isTargetTab || !addonSettings.chatAlerts) return;
    if (document.getElementById("aux-chat-alert")) return;

    activeAlertKey = entryKey || "";

    const overlay = document.createElement("div");
    overlay.id = "aux-chat-alert";
    overlay.dataset.queueKey = activeAlertKey;

    overlay.innerHTML = `
      <div class="aux-chat-alert-backdrop" aria-hidden="true"></div>
      <div class="aux-chat-alert-box" role="alertdialog" aria-live="assertive" aria-label="Waiting chat alert">
        <div class="aux-chat-alert-icon">!</div>
        <div class="aux-chat-alert-kicker">AUX TRACKER</div>
        <div class="aux-chat-alert-title">Chat was waiting..</div>
        <div class="aux-chat-alert-text">A chat has been waiting in your queue longer than your selected alert time.</div>
        <button type="button" class="aux-chat-alert-close">Close</button>
      </div>
    `;

    document.documentElement.appendChild(overlay);

    overlay.querySelector(".aux-chat-alert-close")?.addEventListener("click", () => {
      overlay.remove();
      if (activeAlertKey === entryKey) activeAlertKey = "";
    });
  }

  function findNextDueQueueEntry() {
    const now = Date.now();
    const thresholdMs = getAlertSeconds() * 1000;

    let best = null;

    for (const entry of queueEntries.values()) {
      if (entry.alerted || entry.accepted) continue;

      const item = findQueueItemByIdentity(entry.key);
      if (!item || !queueHasAccept(item)) continue;

      const waitingSeconds = getWaitingSeconds(item);
      const elapsed = now - entry.firstSeenAt;

      if (waitingSeconds >= getAlertSeconds() || elapsed >= thresholdMs) {
        if (!best || entry.firstSeenAt < best.firstSeenAt) best = entry;
      }
    }

    return best;
  }

  function showNextWaitingAlert() {
    if (!addonSettings.chatAlerts) return;
    if (document.getElementById("aux-chat-alert")) return;

    const next = findNextDueQueueEntry();
    if (!next) return;

    next.alerted = true;
    next.alertedAt = Date.now();
    showChatWaitingPopup(next.key);
  }

  function scheduleQueueAlert(entry) {
    clearQueueEntryTimer(entry);

    if (!addonSettings.chatAlerts || entry.alerted || entry.accepted) return;

    const thresholdMs = getAlertSeconds() * 1000;
    const dueAt = entry.firstSeenAt + thresholdMs;
    const remaining = Math.max(50, dueAt - Date.now());

    entry.timer = setTimeout(() => {
      entry.timer = null;

      if (!addonSettings.chatAlerts || entry.alerted || entry.accepted) return;

      const item = findQueueItemByIdentity(entry.key);
      if (!item || !queueHasAccept(item)) {
        entry.lastSeenAt = Date.now();
        return;
      }

      const currentWaiting = getWaitingSeconds(item);
      const elapsed = Date.now() - entry.firstSeenAt;

      if (currentWaiting >= getAlertSeconds() || elapsed >= thresholdMs) {
        showNextWaitingAlert();
      } else {
        scheduleQueueAlert(entry);
      }
    }, remaining);
  }

  function ensureQueueEntry(item, key) {
    const now = Date.now();
    const waitingSeconds = getWaitingSeconds(item);

    let entry = queueEntries.get(key);

    if (!entry) {
      entry = {
        key,
        firstSeenAt: now - Math.max(0, waitingSeconds) * 1000,
        lastSeenAt: now,
        alerted: false,
        accepted: false,
        alertedAt: null,
        timer: null
      };

      queueEntries.set(key, entry);
      scheduleQueueAlert(entry);
      return entry;
    }

    entry.lastSeenAt = now;

    if (!entry.alerted && !entry.accepted && !entry.timer) {
      scheduleQueueAlert(entry);
    }

    return entry;
  }

  function pruneQueueEntries() {
    const now = Date.now();

    for (const [key, entry] of queueEntries) {
      if (now - (entry.lastSeenAt || now) > QUEUE_ABSENCE_GRACE_MS) {
        clearQueueEntryTimer(entry);
        queueEntries.delete(key);

        if (activeAlertKey === key) {
          removeChatWaitingPopup();
        }
      }
    }
  }

  function scanChatQueue() {
    if (!isTargetTab || !addonSettings.chatAlerts) return;

    const items = [...document.querySelectorAll(".queueList .queueItem")];

    for (const item of items) {
      if (!queueHasAccept(item)) continue;

      const key = getQueueIdentity(item);
      if (!key) continue;

      ensureQueueEntry(item, key);
    }

    pruneQueueEntries();
    showNextWaitingAlert();
  }

  async function loadAddonSettings() {
    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      addonSettings = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };
    } catch (_) {}
  }

  async function updatePulse(type) {
    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };

      if (type === "good") {
        current.asat = Number(current.asat || 0) + 1;
      } else if (type === "bad") {
        current.dsat = Number(current.dsat || 0) + 1;
      }
      // "not_sure" intentionally changes no metric.

      await chrome.storage.local.set({ [ADDON_KEY]: current });
      addonSettings = current;
    } catch (_) {}
  }

  async function incrementTotalChatsOnce(identity) {
    if (!identity) return false;

    const storageKey = `totalChatRecorded:${identity}`;

    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };

      // Session-local guard prevents duplicate increments caused by React
      // re-renders while retaining the existing storage architecture.
      if (!window.__auxTotalChatKeys) {
        window.__auxTotalChatKeys = new Set();
      }

      if (window.__auxTotalChatKeys.has(storageKey)) return false;
      window.__auxTotalChatKeys.add(storageKey);

      current.totalChats = Number(current.totalChats || 0) + 1;
      await chrome.storage.local.set({ [ADDON_KEY]: current });
      addonSettings = current;
      return true;
    } catch (_) {
      return false;
    }
  }

  function cleanupPendingAccepts() {
    const now = Date.now();

    for (const [id, pending] of pendingAccepts) {
      if (now - pending.clickedAt > 15000) {
        pendingAccepts.delete(id);
      }
    }
  }

  function observeAcceptClick(button) {
    const queueItem = button?.closest?.(".queueItem");
    const queueIdentity = queueItem ? getQueueIdentity(queueItem) : "";
    const previousChatIdentity = getCurrentChatIdentity();

    // Requirement: the waiting alert disappears immediately on native Accept.
    removeChatWaitingPopup();

    const pendingId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;

    pendingAccepts.set(pendingId, {
      clickedAt: Date.now(),
      queueIdentity,
      previousChatIdentity
    });

    const entry = queueIdentity ? queueEntries.get(queueIdentity) : null;
    if (entry) {
      entry.accepted = true;
      clearQueueEntryTimer(entry);
    }

    // Observe-only. The native Accept event continues unchanged.
  }

  function confirmAcceptedChats() {
    cleanupPendingAccepts();

    const now = Date.now();

    for (const [pendingId, pending] of pendingAccepts) {
      if (now - pending.clickedAt > 10000) continue;

      const header = getHeader();
      const currentIdentity = getCurrentChatIdentity(header);

      if (!currentIdentity) continue;

      const queueItem = pending.queueIdentity
        ? findQueueItemByIdentity(pending.queueIdentity)
        : null;

      const identityChanged =
        !!pending.previousChatIdentity &&
        currentIdentity !== pending.previousChatIdentity;

      const queueNoLongerAcceptable =
        !!pending.queueIdentity &&
        (!queueItem || !queueHasAccept(queueItem));

      // A real accepted chat either opens a new/current chat identity or
      // removes the accepted queue item/Accept control.
      if (identityChanged || queueNoLongerAcceptable || !pending.previousChatIdentity) {
        pendingAccepts.delete(pendingId);
        incrementTotalChatsOnce(currentIdentity);
      }
    }
  }

  function chatIsActuallyClosed(state) {
    if (!state) return false;

    const currentHeader = getHeader();

    // Lowe's removed the chat header entirely.
    if (!currentHeader) return true;

    const currentIdentity = getCurrentChatIdentity(currentHeader);

    // A different chat rendered in the same header means the previous one
    // has been closed.
    if (
      state.chatIdentity &&
      currentIdentity &&
      currentIdentity !== state.chatIdentity
    ) {
      return true;
    }

    // React may retain .chatHeader while clearing/rebuilding its children.
    const name = normalizeText(currentHeader.querySelector(".name")?.textContent);
    const sub = normalizeText(currentHeader.querySelector(".sub")?.textContent);

    return !name && !sub;
  }

  function getNativeCloseButton(header = getHeader()) {
    if (!header) return null;

    return [...header.querySelectorAll("button")].find(button => {
      const label = getButtonLabel(button);
      return label === "close" ||
        label === "close chat" ||
        label === "close conversation";
    }) || null;
  }

  function captureEndChatIntent(button) {
    const header = getHeader();
    if (!header) return;

    const identity = getCurrentChatIdentity(header);
    if (!identity) return;

    // Reset only if this is a genuinely different chat.
    if (
      agentEndState?.chatIdentity === identity &&
      agentEndState.phase !== "CLOSED"
    ) {
      return;
    }

    agentEndState = {
      chatIdentity: identity,
      chatRoot: header,
      initiatedAt: Date.now(),
      phase: "END_REQUESTED",
      closeAvailable: false,
      closeClickedAt: null
    };

    // Native Lowe's End Chat click is untouched.
  }

  function observeCloseAvailability() {
    if (!agentEndState) return;

    const header = getHeader();
    if (!header) return;

    const identity = getCurrentChatIdentity(header);
    if (identity && identity !== agentEndState.chatIdentity) return;

    const closeButton = getNativeCloseButton(header);
    if (!closeButton) return;

    agentEndState.closeAvailable = true;
    agentEndState.phase = "NATIVE_CLOSE_AVAILABLE";
  }

  function captureNativeCloseClick(button) {
    if (!agentEndState) return;

    const header = getHeader();
    const identity = getCurrentChatIdentity(header);

    if (!header || identity !== agentEndState.chatIdentity) return;

    const nativeClose = getNativeCloseButton(header);

    if (nativeClose && button !== nativeClose) return;

    // This is only an observation. Do not cancel or replace the native click.
    agentEndState.phase = "NATIVE_CLOSE_CLICKED";
    agentEndState.closeClickedAt = Date.now();
  }

  function finishClosedChatIfReady() {
    if (!agentEndState) return;

    const state = agentEndState;

    if (Date.now() - state.initiatedAt > 60000) {
      // End Chat was cancelled, ignored, or never completed.
      agentEndState = null;
      return;
    }

    // Do not classify the chat from End Chat itself or from Close appearing.
    if (state.phase !== "NATIVE_CLOSE_CLICKED") return;

    if (!chatIsActuallyClosed(state)) return;

    agentEndState = null;

    if (!addonSettings.pulseTracker) return;
    if (!state.chatIdentity) return;

    showPulseTracker(state.chatIdentity);
  }

  function showPulseTracker(chatIdentity) {
    if (!addonSettings.pulseTracker) return;
    if (endChatPopup) return;
    if (pulseShownForChats.has(chatIdentity)) return;

    pulseShownForChats.add(chatIdentity);

    const overlay = document.createElement("div");
    overlay.id = "aux-end-chat-popup";
    overlay.dataset.chatIdentity = chatIdentity;

    overlay.innerHTML = `
      <div class="aux-end-chat-backdrop" aria-hidden="true"></div>
      <div class="aux-end-chat-box" role="dialog" aria-modal="true" aria-labelledby="auxEndChatTitle">
        <div class="aux-end-chat-kicker">CHAT COMPLETE</div>
        <div class="aux-end-chat-title" id="auxEndChatTitle">How was the Chat?</div>
        <div class="aux-end-chat-sub">Select one result to record the Pulse.</div>
        <div class="aux-end-chat-actions">
          <button type="button" class="aux-sat-btn aux-good">GOOD</button>
          <button type="button" class="aux-sat-btn aux-not-sure">NOT SURE</button>
          <button type="button" class="aux-sat-btn aux-bad">BAD</button>
        </div>
      </div>
    `;

    document.documentElement.appendChild(overlay);
    endChatPopup = overlay;

    let recorded = false;

    const remove = () => {
      if (overlay.isConnected) overlay.remove();
      if (endChatPopup === overlay) endChatPopup = null;
    };

    const finish = async result => {
      if (recorded) return;
      recorded = true;

      await updatePulse(result);
      remove();
    };

    overlay.querySelector(".aux-good")?.addEventListener("click", () => finish("good"));
    overlay.querySelector(".aux-not-sure")?.addEventListener("click", () => finish("not_sure"));
    overlay.querySelector(".aux-bad")?.addEventListener("click", () => finish("bad"));
  }

  function handleNativeClickObservation(event) {
    if (!isTargetTab) return;

    const target = event.target;
    if (!target) return;

    if (isAcceptButton(target)) {
      observeAcceptClick(target.closest("button"));
    }

    if (isEndChatButton(target)) {
      captureEndChatIntent(target.closest("button"));
    }

    if (isCloseChatButton(target)) {
      captureNativeCloseClick(target.closest("button"));
    }

    // Agent-name navigation: open the extension's own index.html in a new tab.
    const agentName = target.closest?.(".agentName");
    if (agentName) {
      chrome.runtime.sendMessage({ type: "OPEN_PROFILE" }).catch(() => {});
    }
  }

  // Capture phase is observation only; it never alters the native event.
  document.addEventListener("click", handleNativeClickObservation, true);

  function startAppObserver() {
    if (appObserver) return;

    appObserver = new MutationObserver(() => {
      scanChatQueue();
      confirmAcceptedChats();
      observeCloseAvailability();
      finishClosedChatIfReady();
    });

    appObserver.observe(document.documentElement || document, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: [
        "data-chat-id",
        "data-session-id",
        "data-request-id",
        "data-conversation-id",
        "data-interaction-id",
        "data-customer-id",
        "data-contact-id",
        "aria-label",
        "title",
        "class"
      ]
    });

    if (!queueScanTimer) {
      queueScanTimer = setInterval(() => {
        scanChatQueue();
        confirmAcceptedChats();
        observeCloseAvailability();
        finishClosedChatIfReady();
      }, 500);
    }
  }

  function stopAppObserver() {
    if (queueScanTimer) clearInterval(queueScanTimer);
    queueScanTimer = null;

    if (appObserver) appObserver.disconnect();
    appObserver = null;

    for (const entry of queueEntries.values()) {
      clearQueueEntryTimer(entry);
    }

    queueEntries.clear();
    pendingAccepts.clear();
    agentEndState = null;

    removeChatWaitingPopup();

    endChatPopup?.remove();
    endChatPopup = null;
  }

  function applyAddonSettings(next) {
    const previous = addonSettings;
    addonSettings = { ...DEFAULT_ADDONS, ...(next || {}) };

    if (!addonSettings.chatAlerts) {
      for (const entry of queueEntries.values()) {
        clearQueueEntryTimer(entry);
      }
      queueEntries.clear();
      removeChatWaitingPopup();
    } else if (
      !previous.chatAlerts ||
      Number(previous.chatInterval) !== Number(addonSettings.chatInterval)
    ) {
      for (const entry of queueEntries.values()) {
        if (!entry.alerted && !entry.accepted) scheduleQueueAlert(entry);
      }
      scanChatQueue();
    }

    if (!addonSettings.pulseTracker) {
      endChatPopup?.remove();
      endChatPopup = null;
    }

    if (isTargetTab) {
      startAppObserver();
      if (addonSettings.chatAlerts) scanChatQueue();
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[ADDON_KEY]) return;
    applyAddonSettings(changes[ADDON_KEY].newValue || {});
  });

  let targetStateTimer = null;

  function syncTargetState() {
    requestTargetTabState();
  }

  async function initializeAddon() {
    await loadAddonSettings();

    // The selected target is the tab, not a specific SPA route. Therefore
    // /chat, /cases, /search, /knowledge and future routes continue working.
    syncTargetState();

    if (!targetStateTimer) {
      targetStateTimer = setInterval(syncTargetState, 1500);
    }
  }

  initializeAddon();
}
