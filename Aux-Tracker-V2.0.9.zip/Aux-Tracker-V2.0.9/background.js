const STORAGE_KEY = "auxTrackerState";

const DEFAULT_STATE = {
  running: false,
  targetTabId: null,
  targetUrl: "",
  targetTitle: "",
  currentStatus: "",
  statusStartedAt: null,
  lastSeenAt: null,
  history: [],
  lastStoppedReason: "",
  updatedAt: Date.now()
};

async function getState() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  return { ...DEFAULT_STATE, ...(result[STORAGE_KEY] || {}) };
}

async function setState(state) {
  state.updatedAt = Date.now();
  await chrome.storage.local.set({ [STORAGE_KEY]: state });
}

function normalizeStatus(status) {
  return String(status || "").replace(/\s+/g, " ").trim();
}

function classify(status) {
  const s = normalizeStatus(status).toLowerCase();
  if (s === "offline" || s.includes("offline")) return "offline";
  if (s === "break" || s.includes("on break") || s.startsWith("break")) return "break";
  if (s === "lunch" || s.includes("lunch")) return "lunch";
  if (["available", "meeting", "training", "coaching"].includes(s)) return "login";
  return "other";
}

async function finishCurrent(state, endedAt = Date.now()) {
  if (!state.currentStatus || !state.statusStartedAt) return;
  const durationMs = Math.max(0, endedAt - state.statusStartedAt);
  if (durationMs > 0) {
    state.history.push({
      status: state.currentStatus,
      startedAt: state.statusStartedAt,
      endedAt,
      durationMs
    });
  }
}

async function processStatus(senderTabId, status) {
  const state = await getState();
  if (!state.running) return;
  if (senderTabId !== state.targetTabId) return;

  const nextStatus = normalizeStatus(status);
  if (!nextStatus) return;

  const now = Date.now();
  if (!state.currentStatus) {
    state.currentStatus = nextStatus;
    state.statusStartedAt = now;
    state.lastSeenAt = now;
    await setState(state);
    return;
  }

  if (state.currentStatus === nextStatus) {
    state.lastSeenAt = now;
    await setState(state);
    return;
  }

  await finishCurrent(state, now);
  state.currentStatus = nextStatus;
  state.statusStartedAt = now;
  state.lastSeenAt = now;

  if (classify(nextStatus) === "offline") {
    await finishCurrent(state, now);
    state.currentStatus = "Offline";
    state.statusStartedAt = now;
    state.running = false;
    state.lastStoppedReason = "offline";
    state.lastSeenAt = now;
  }

  await setState(state);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === "START_TRACKING") {
        const tab = await chrome.tabs.get(message.tabId);
        const old = await getState();
        const state = { ...old };

        // If a previous session was left active, close its current interval before restarting.
        if (state.running && state.currentStatus && state.statusStartedAt) {
          await finishCurrent(state, Date.now());
        }

        state.running = true;
        state.targetTabId = tab.id;
        state.targetUrl = tab.url || "";
        state.targetTitle = tab.title || "";
        state.currentStatus = "";
        state.statusStartedAt = null;
        state.lastSeenAt = Date.now();
        state.lastStoppedReason = "";
        await setState(state);

        try {
          await chrome.tabs.sendMessage(tab.id, { type: "START_MONITORING" });
        } catch (_) {
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id, allFrames: true },
              files: ["content.js"]
            });
          } catch (_) {}
        }

        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "STOP_TRACKING") {
        const state = await getState();
        if (state.running && state.currentStatus && state.statusStartedAt) {
          await finishCurrent(state, Date.now());
        }
        state.running = false;
        state.currentStatus = "";
        state.statusStartedAt = null;
        state.lastSeenAt = Date.now();
        state.lastStoppedReason = "manual";
        await setState(state);

        if (state.targetTabId != null) {
          try {
            await chrome.tabs.sendMessage(state.targetTabId, { type: "STOP_MONITORING" });
          } catch (_) {}
        }
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "GET_STATE") {
        sendResponse({ ok: true, state: await getState() });
        return;
      }

      if (message?.type === "STATUS_UPDATE") {
        await processStatus(sender?.tab?.id, message.status);
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "CLEAR_HISTORY") {
        const state = await getState();
        state.history = [];
        await setState(state);
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "OPEN_DASHBOARD") {
        const url = chrome.runtime.getURL("dashboard.html");
        await chrome.tabs.create({ url });
        sendResponse({ ok: true });
        return;
      }
    } catch (error) {
      sendResponse({ ok: false, error: String(error) });
    }
  })();
  return true;
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const state = await getState();
  if (!state.running || tabId !== state.targetTabId) return;

  if (changeInfo.status === "complete") {
    state.targetUrl = tab.url || state.targetUrl;
    state.targetTitle = tab.title || state.targetTitle;
    await setState(state);
    try {
      await chrome.tabs.sendMessage(tabId, { type: "START_MONITORING" });
    } catch (_) {}
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await getState();
  if (!state.running || tabId !== state.targetTabId) return;

  if (state.currentStatus && state.statusStartedAt) {
    await finishCurrent(state, Date.now());
  }
  state.running = false;
  state.currentStatus = "";
  state.statusStartedAt = null;
  state.lastStoppedReason = "target-tab-closed";
  await setState(state);
});

chrome.runtime.onInstalled.addListener(async () => {
  const state = await getState();
  await setState(state);
});
