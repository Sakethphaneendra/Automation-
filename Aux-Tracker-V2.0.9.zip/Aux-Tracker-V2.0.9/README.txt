AUX TRACKER V1.09

Install:
1. Open chrome://extensions
2. Enable Developer mode.
3. Click Load unpacked.
4. Select this folder.

Usage:
1. Open the target website containing .agentStatusControls.
2. Click the Aux Tracker extension icon.
3. Click START.
4. The active tab becomes the only tracked tab.
5. The dashboard opens after about 2 seconds.

V1.09 changes:
- Persistent tracker data in chrome.storage.local.
- Dashboard data survives dashboard close/reopen and target-page refresh.
- Replaced AUX Summary and History with four live timers:
  Login Hours, Break, Lunch, Total Floor Time.
- Login Hours counts Available, Meeting, Training, Coaching.
- Break and Lunch each use a 30-minute allowance and show overage.
- Offline time is excluded from Total Floor Time.
- All other non-Offline tracked AUX time counts toward Total Floor Time.
- Top branding now shows Aux Tracker and 24/7.ai.
- Removed popup Stop Tracking button.
- Added live India Standard Time/date.
- Saketh credit is larger and clickable; it opens a blank tab for future design.


AUX TRACKER V2.0.9 changes:
- Total Chats is recorded only after an observed native Lowe's Accept click results in a newly opened/confirmed chat.
- Removed Total Chat increment from Pulse/End Chat flow.
- Native Lowe's Accept and End Chat events are never cancelled or stopped.
- Pulse Tracker waits for the active chat to actually close after an observed agent End Chat click.
- Customer-initiated chat closure does not trigger Pulse Tracker because there is no recorded agent End Chat intent.
- Pulse Close/X records no ASAT, DSAT, or Total Chat.
- Chat Alerts monitor /chat, /knowledge, /cases and /search as one SPA environment.
- Waiting-chat identity does not use changing "Waiting for XX s" text.
- Waiting-chat timers survive supported SPA route changes and DOM re-renders.
- One waiting chat can trigger only one alert until it is no longer tracked.
- Chat Alerts OFF clears timers and the visible alert.
- The add-on uses one application MutationObserver and one queue scan interval; route changes do not create new monitors.
- The extension is observation-only and does not use preventDefault(), stopPropagation(), or stopImmediatePropagation().
