AUX Tracker V3.0.4

IMPORTANT FIX: AUX detection now targets the real <select> inside .agentStatusControls,
reads select.value/selectedOptions, ignores the 'Select status' placeholder, re-attaches
when React replaces the SELECT, and polls the native value so React-controlled changes
are detected reliably.

AUX Tracker V3.0.3 - Target Tab

This build treats the tab where START is pressed as the only Lowe's/AUX target tab.
There is no Lowe's route allow-list. SPA navigation inside the target tab does not reset monitoring.

Native-site safety:
- No preventDefault()
- No stopPropagation()
- No stopImmediatePropagation()
- No replacement/override of Lowe's Accept or End Chat functions
- Accept and End Chat are observed only

Core rules:
- Total Chats +1 only after an observed Accept click is followed by a newly opened active chat.
- End Chat never increments Total Chats.
- Agent-initiated native End Chat is allowed to complete first; Pulse appears only after actual chat closure.
- Customer-initiated closure does not show Pulse.
- Good +1 ASAT; Bad +1 DSAT; Close/X changes no counters.
- Waiting alerts are tied to stable queue identity and survive SPA route changes in the selected tab.
- One queue monitor and one app MutationObserver are used per target page.

Demo test:
A standalone Lowe's-like demo page is included outside the extension package in the AUX Tracker V3.0.3 Demo ZIP.
