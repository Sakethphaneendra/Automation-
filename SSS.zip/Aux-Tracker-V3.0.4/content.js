(() => {
  if (window.__auxTrackerStatusMonitorInstalled) return;
  window.__auxTrackerStatusMonitorInstalled = true;

  let running = false;
  let pollTimer = null;
  let statusObserver = null;
  let watchedSelect = null;
  let lastStatus = "";

  /*
   * Lowe's renders:
   * <div class="agentStatusControls"> ... <select class="select"> ... </select>
   *
   * The old build watched the container itself. React can replace the
   * <select> without changing the container, and a controlled React select
   * does not reliably expose its selected state through container text.
   * Always locate the actual SELECT and read its .value/selectedOptions.
   */

  function getStatusSelect() {
    const container = document.querySelector(".agentStatusControls");
    if (!container) return null;

    // Primary selector used by the supplied Lowe's DOM.
    const select = container.querySelector("select.select, select");
    if (select) return select;

    return null;
  }

  function readStatus(select) {
    if (!select) return "";

    // Native SELECT is the source of truth for a React controlled select.
    const value = String(select.value ?? "").trim();
    const option =
      select.selectedOptions?.[0] ||
      select.options?.[select.selectedIndex];

    const label = String(option?.textContent || "").replace(/\s+/g, " ").trim();

    // Ignore the placeholder. It is not an AUX state.
    if (!value || value.toLowerCase() === "select status") return "";

    // Prefer the visible label because dashboard/history should show
    // "On Break", "Available - Case", "System Issue", etc.
    return label || value;
  }

  function sendStatus(status) {
    if (!running || !status || status === lastStatus) return;
    lastStatus = status;

    chrome.runtime.sendMessage({
      type: "STATUS_UPDATE",
      status
    }).catch(() => {});
  }

  function attach(select) {
    if (!select || select === watchedSelect) return;

    if (watchedSelect) {
      try {
        watchedSelect.removeEventListener("change", onStatusChange, true);
      } catch (_) {}
    }

    watchedSelect = select;
    select.addEventListener("change", onStatusChange, true);

    // Read immediately in case the agent was already in an AUX state
    // before the extension started.
    sendStatus(readStatus(select));
  }

  function onStatusChange(event) {
    const select = event.currentTarget || watchedSelect;
    sendStatus(readStatus(select));
  }

  function tick() {
    if (!running) return;

    const select = getStatusSelect();

    // React may destroy/recreate the SELECT while keeping
    // .agentStatusControls. Re-attach whenever its identity changes.
    if (select !== watchedSelect) {
      attach(select);
    }

    if (select) {
      sendStatus(readStatus(select));
    }
  }

  function start() {
    if (running) {
      tick();
      return;
    }

    running = true;

    // Polling is deliberately kept because React can change the native
    // select's .value without producing an attribute mutation.
    if (!pollTimer) {
      pollTimer = setInterval(tick, 250);
    }

    if (!statusObserver) {
      statusObserver = new MutationObserver(() => tick());

      statusObserver.observe(document.documentElement || document, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: [
          "value",
          "selected",
          "aria-selected",
          "class"
        ]
      });
    }

    tick();
  }

  function stop() {
    running = false;

    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;

    if (statusObserver) statusObserver.disconnect();
    statusObserver = null;

    if (watchedSelect) {
      try {
        watchedSelect.removeEventListener("change", onStatusChange, true);
      } catch (_) {}
    }

    watchedSelect = null;
    lastStatus = "";
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "START_MONITORING") start();
    if (message?.type === "STOP_MONITORING") stop();
  });

  // Recover when the content script was loaded before START was pressed.
  chrome.runtime.sendMessage({ type: "GET_STATE" })
    .then((res) => {
      if (res?.state?.running && res.state.targetTabId != null) {
        start();
      }
    })
    .catch(() => {});
})();

function normalizeText(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

/* =========================
   AUX ADD-ON OBSERVERS
   =========================
   This section is intentionally passive:
   - no preventDefault()
   - no stopPropagation()
   - no stopImmediatePropagation()
   - no replacement of Lowe's buttons/functions
   - no modification of Lowe's application state
*/
function injectAuxStyles() {
  if (document.getElementById("aux-tracker-target-style")) return;
  const link = document.createElement("link");
  link.id = "aux-tracker-target-style";
  link.rel = "stylesheet";
  link.href = chrome.runtime.getURL("target-overlays.css");
  (document.head || document.documentElement).appendChild(link);
}

injectAuxStyles();

{
  // Run the webpage add-on layer in every frame. Lowe's can render
  // parts of the chat/queue UI inside an iframe; restricting this layer
  // to window.top makes those parts invisible to the extension.
  const ADDON_KEY = "auxTrackerAddons";
  const DEFAULT_ADDONS = {
    chatAlerts: false,
    chatInterval: 15,
    pulseTracker: false,
    asat: 0,
    dsat: 0,
    totalChats: 0
  };

  // No Lowe's URL/path allow-list is used. The extension is scoped to
  // the tab selected when tracking is started. SPA navigation in that tab
  // remains part of the same tracking session.
  let isTargetTab = false;

  // Single monitor state. These are intentionally created once per page.
  let addonSettings = { ...DEFAULT_ADDONS };
  const queueEntries = new Map();
  const pendingAccepts = new Map();
  const handledAgentChats = new Set();
  let agentEndState = null;
  let endChatPopup = null;
  let appObserver = null;
  let queueScanTimer = null;
  const QUEUE_ABSENCE_GRACE_MS = 4000;

  // Tracks which waiting-chat queue entry (if any) currently owns the
  // single visible waiting-chat alert, so only one popup is ever shown.
  let activeAlertEntryKey = null;

  // ===== Requirement 3: agent-name -> open bundled index.html in a NEW tab =====
  // This is intentionally independent of the AUX tracking on/off state and
  // is scoped to the Lowe's site only, so it never fires on the extension's
  // own pages (popup/dashboard/index) which also mention the same name.
  const ON_LOWES_SITE = /(^|\.)lowes\.com$/i.test(location.hostname || "");
  const AGENT_NAME = "saketh phaneendra";
  let indexPageOpenInFlight = false;

  function openIndexPageInNewTab() {
    if (indexPageOpenInFlight) return;
    indexPageOpenInFlight = true;
    chrome.runtime.sendMessage({ type: "OPEN_INDEX_PAGE" })
      .catch(() => {})
      .finally(() => { indexPageOpenInFlight = false; });
  }

  function isAgentNameTarget(target) {
    if (!ON_LOWES_SITE || !target) return false;

    let el = target.nodeType === 1 ? target : target.parentElement;
    // Climb a few ancestors to find the smallest element whose own visible
    // text is exactly the agent name (handles the name being split across
    // inline child nodes) without matching large unrelated containers.
    for (let i = 0; el && i < 5; i++, el = el.parentElement) {
      const text = normalizeText(el.textContent).toLowerCase();
      if (!text) continue;
      if (text === AGENT_NAME) return true;
      if (text.length > 80) break;
    }
    return false;
  }

  // The background service worker tells this tab when it becomes the target.
  // This listener only changes AUX internal state; it never touches Lowe's events.
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "TARGET_TAB_STATE") {
      const next = !!message.isTargetTab;
      if (next === isTargetTab) return;
      isTargetTab = next;
      if (isTargetTab) {
        startAppObserver();
        if (addonSettings.chatAlerts) scanChatQueue();
      } else {
        stopAppObserver();
      }
    }
  });

  function requestTargetTabState() {
    chrome.runtime.sendMessage({ type: "IS_TARGET_TAB" }).then(res => {
      const next = !!res?.isTargetTab;
      if (next === isTargetTab) return;
      isTargetTab = next;
      if (isTargetTab) {
        startAppObserver();
        if (addonSettings.chatAlerts) scanChatQueue();
      } else {
        stopAppObserver();
      }
    }).catch(() => {});
  }

  function getAlertSeconds() {
    return Math.max(5, Math.min(30, Number(addonSettings.chatInterval) || 15));
  }

  function readAttributeIdentity(root) {
    if (!root) return "";

    const attrs = [
      "data-chat-id",
      "data-session-id",
      "data-request-id",
      "data-conversation-id",
      "data-interaction-id",
      "data-customer-id",
      "data-contact-id",
      "data-chatid",
      "data-sessionid",
      "data-requestid",
      "data-conversationid",
      "data-interactionid"
    ];

    const nodes = [root, ...root.querySelectorAll("*")];
    for (const node of nodes) {
      for (const attr of attrs) {
        const value = normalizeText(node.getAttribute?.(attr));
        if (value) return `${attr}:${value}`;
      }
    }

    return "";
  }

  function getHeader() {
    return document.querySelector(".chatHeader");
  }

  function getCurrentChatIdentity() {
    const header = getHeader();
    if (!header) return "";

    const strongId = readAttributeIdentity(header);
    if (strongId) return strongId;

    const name = normalizeText(header.querySelector(".name")?.textContent);
    const sub = normalizeText(header.querySelector(".sub")?.textContent);

    // Fallback only when Lowe's exposes no obvious stable identifier.
    return [name, sub].filter(Boolean).join("|");
  }

  function getQueueIdentity(item) {
    if (!item) return "";

    const strongId = readAttributeIdentity(item);
    if (strongId) return strongId;

    const values = [];

    const name = normalizeText(item.querySelector(".queueLeft .name")?.textContent);
    if (name) values.push(`name:${name}`);

    for (const sub of item.querySelectorAll(".queueLeft .sub")) {
      const text = normalizeText(sub.textContent);
      if (!text) continue;
      if (/^waiting\s+for\s+\d+\s*s?$/i.test(text)) continue;
      values.push(`sub:${text}`);
    }

    // Never use the changing "Waiting for XX s" text as identity.
    return values.join("|") || "";
  }

  function getWaitingSeconds(item) {
    const text = normalizeText(item?.textContent);
    const match = text.match(/waiting\s+for\s+(\d+)\s*s?/i);
    return match ? Number(match[1]) : 0;
  }

  function queueHasAccept(item) {
    return [...item.querySelectorAll("button")].some(button => {
      const label = normalizeText(
        button.getAttribute("aria-label") ||
        button.getAttribute("title") ||
        button.textContent
      ).toLowerCase();

      return label === "accept" || label.includes("accept");
    });
  }

  function findQueueItemByIdentity(key) {
    return [...document.querySelectorAll(".queueList .queueItem")]
      .find(item => getQueueIdentity(item) === key) || null;
  }

  function clearQueueEntryTimer(entry) {
    if (entry?.timer) {
      clearTimeout(entry.timer);
      entry.timer = null;
    }
  }

  function removeChatWaitingPopup() {
    document.getElementById("aux-chat-alert")?.remove();
    activeAlertEntryKey = null;
  }

  function showChatWaitingPopup(key) {
    if (!isTargetTab || !addonSettings.chatAlerts) return;
    if (document.getElementById("aux-chat-alert")) return;

    activeAlertEntryKey = key || activeAlertEntryKey;

    const overlay = document.createElement("div");
    overlay.id = "aux-chat-alert";

    overlay.innerHTML = `
      <div class="aux-chat-alert-backdrop"></div>
      <div class="aux-chat-alert-box" role="alertdialog" aria-modal="true">
        <div class="aux-chat-alert-icon">!</div>
        <div class="aux-chat-alert-kicker">AUX TRACKER</div>
        <div class="aux-chat-alert-title">Chat was waiting..</div>
        <div class="aux-chat-alert-text">A chat has been waiting in your queue longer than your selected alert time.</div>
        <button type="button" class="aux-chat-alert-close">Close</button>
      </div>
    `;

    document.documentElement.appendChild(overlay);

    const close = () => {
      removeChatWaitingPopup();
      // Manually dismissing lets the next already-due waiting chat (if any)
      // take the single visible alert slot.
      tryPromoteNextAlert();
    };
    overlay.querySelector(".aux-chat-alert-backdrop")?.addEventListener("click", close);
    overlay.querySelector(".aux-chat-alert-close")?.addEventListener("click", close);
  }

  // Requirement 5/6: only ONE waiting-chat popup is ever shown at a time.
  // Individual entries become "due" independently (see scheduleQueueAlert),
  // but only this function is allowed to actually display the popup and
  // mark an entry as alerted, so a due-but-blocked entry is never silently
  // marked "alerted" without ever being shown.
  function tryPromoteNextAlert() {
    if (!isTargetTab || !addonSettings.chatAlerts) return;
    if (document.getElementById("aux-chat-alert")) return; // one at a time

    const thresholdMs = getAlertSeconds() * 1000;
    const now = Date.now();
    let candidate = null;

    for (const entry of queueEntries.values()) {
      if (entry.alerted) continue;
      if (now - entry.firstSeenAt < thresholdMs) continue;

      const item = findQueueItemByIdentity(entry.key);
      if (!item || !queueHasAccept(item)) continue;

      if (!candidate || entry.firstSeenAt < candidate.firstSeenAt) candidate = entry;
    }

    if (!candidate) return;

    candidate.alerted = true;
    candidate.alertedAt = now;
    showChatWaitingPopup(candidate.key);
  }

  function scheduleQueueAlert(entry) {
    clearQueueEntryTimer(entry);

    if (!addonSettings.chatAlerts) return;
    if (entry.alerted) return;

    const thresholdMs = getAlertSeconds() * 1000;
    const dueAt = entry.firstSeenAt + thresholdMs;
    const remaining = Math.max(0, dueAt - Date.now());

    const fire = () => {
      entry.timer = null;

      if (!addonSettings.chatAlerts || entry.alerted) return;
      const item = findQueueItemByIdentity(entry.key);
      if (!item || !queueHasAccept(item)) {
        // Keep the stable entry alive across transient SPA renders/navigation.
        entry.lastSeenAt = Date.now();
        return;
      }

      const currentWaiting = getWaitingSeconds(item);
      const elapsed = Date.now() - entry.firstSeenAt;

      if (currentWaiting >= getAlertSeconds() || elapsed >= thresholdMs) {
        // This entry is due. It only actually becomes "alerted" once
        // tryPromoteNextAlert shows it (it may have to wait behind another
        // chat's currently visible popup - the periodic scan retries it).
        tryPromoteNextAlert();
        return;
      }

      scheduleQueueAlert(entry);
    };

    entry.timer = setTimeout(fire, Math.max(50, remaining));
  }

  function ensureQueueEntry(item, key) {
    const now = Date.now();
    const waitingSeconds = getWaitingSeconds(item);
    let entry = queueEntries.get(key);

    if (!entry) {
      entry = {
        key,
        firstSeenAt: now - Math.max(0, waitingSeconds) * 1000,
        lastSeenAt: now,
        alerted: false,
        alertedAt: null,
        timer: null
      };
      queueEntries.set(key, entry);
      scheduleQueueAlert(entry);
      return entry;
    }

    entry.lastSeenAt = now;

    // If the threshold setting changes while this same chat is waiting,
    // recalculate from the original waiting start instead of restarting it.
    // Once an entry is already past its own due time but still unalerted
    // (blocked behind another visible popup), the periodic scan's
    // tryPromoteNextAlert() safety net handles it - re-arming a timer here
    // too would cause a tight, wasteful re-fire loop.
    const alreadyDue = now - entry.firstSeenAt >= getAlertSeconds() * 1000;
    if (!entry.alerted && !entry.timer && !alreadyDue) {
      scheduleQueueAlert(entry);
    }

    return entry;
  }

  function pruneQueueEntries() {
    const now = Date.now();
    for (const [key, entry] of queueEntries) {
      if (now - (entry.lastSeenAt || now) > QUEUE_ABSENCE_GRACE_MS) {
        clearQueueEntryTimer(entry);
        queueEntries.delete(key);
      }
    }
  }

  function scanChatQueue() {
    if (!isTargetTab || !addonSettings.chatAlerts) return;

    const items = [...document.querySelectorAll(".queueList .queueItem")];

    for (const item of items) {
      if (!queueHasAccept(item)) continue;

      const key = getQueueIdentity(item);
      if (!key) continue;

      ensureQueueEntry(item, key);
    }

    pruneQueueEntries();

    // Safety net: promote a due entry if the popup slot is currently free
    // (covers cases where a fire() timer was blocked by another visible
    // popup and needs a later retry).
    tryPromoteNextAlert();
  }

  async function loadAddonSettings() {
    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      addonSettings = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };
    } catch (_) {}
  }

  async function updatePulse(type) {
    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };

      if (type === "good") current.asat = Number(current.asat || 0) + 1;
      if (type === "bad") current.dsat = Number(current.dsat || 0) + 1;

      await chrome.storage.local.set({ [ADDON_KEY]: current });
      addonSettings = current;
    } catch (_) {}
  }

  async function incrementTotalChatsOnce(identity) {
    if (!identity) return false;
    if (handledAgentChats.has(identity)) return false;

    handledAgentChats.add(identity);

    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };
      current.totalChats = Number(current.totalChats || 0) + 1;
      await chrome.storage.local.set({ [ADDON_KEY]: current });
      addonSettings = current;
      return true;
    } catch (_) {
      handledAgentChats.delete(identity);
      return false;
    }
  }

  function cleanupPendingAccepts() {
    const now = Date.now();
    for (const [id, pending] of pendingAccepts) {
      if (now - pending.clickedAt > 15000) pendingAccepts.delete(id);
    }
  }

  function findPendingAcceptForChat(identity) {
    if (!identity) return null;

    for (const [id, pending] of pendingAccepts) {
      if (pending.expectedIdentity && pending.expectedIdentity === identity) {
        return [id, pending];
      }
    }

    // If Lowe's did not expose a usable ID, only a newly-opened/different
    // chat can confirm the observed Accept click.
    for (const [id, pending] of pendingAccepts) {
      if (pending.previousChatIdentity && pending.previousChatIdentity === identity) continue;
      if (Date.now() - pending.clickedAt <= 10000) return [id, pending];
    }

    return null;
  }

  function confirmAcceptedChat() {
    cleanupPendingAccepts();

    const identity = getCurrentChatIdentity();
    if (!identity) return;

    // If the same chat was already open before Accept was clicked, that is
    // not confirmation of a newly accepted queue chat.
    for (const pending of pendingAccepts.values()) {
      if (pending.previousChatIdentity && pending.previousChatIdentity === identity) {
        pending.lastCheckedIdentity = identity;
      }
    }

    const match = findPendingAcceptForChat(identity);
    if (!match) return;

    const [pendingId, pending] = match;
    pendingAccepts.delete(pendingId);

    // Only the successful open-chat confirmation can increment Total Chats.
    incrementTotalChatsOnce(identity);
  }

  function observeAcceptClick(button) {
    const queueItem = button.closest(".queueItem");
    const queueIdentity = queueItem ? getQueueIdentity(queueItem) : "";

    // Requirement 4: clicking native Accept must immediately hide the
    // waiting-chat alert, regardless of which entry currently owns it.
    removeChatWaitingPopup();

    if (queueIdentity && queueEntries.has(queueIdentity)) {
      clearQueueEntryTimer(queueEntries.get(queueIdentity));
      queueEntries.delete(queueIdentity);
    }

    const pendingId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    pendingAccepts.set(pendingId, {
      clickedAt: Date.now(),
      queueIdentity,
      previousChatIdentity: getCurrentChatIdentity(),
      expectedIdentity: "",
      confirmed: false
    });

    // Requirement 5/6: if another chat is still waiting, its alert can now
    // be promoted to the single visible slot.
    tryPromoteNextAlert();

    // Do not touch the native event. No preventDefault/stopPropagation calls.
  }

  function isAcceptButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;

    const label = normalizeText(
      button.getAttribute("aria-label") ||
      button.getAttribute("title") ||
      button.textContent
    ).toLowerCase();

    return label === "accept" || label.includes("accept");
  }

  function isEndChatButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;

    return normalizeText(
      button.getAttribute("aria-label") ||
      button.getAttribute("title") ||
      button.textContent
    ).toLowerCase() === "end chat";
  }

  // Requirement 17: after a successful native End Chat, Lowe's swaps the
  // same header control's label to "Close". This is scoped to .chatHeader
  // only so the extension's own overlay "×" close buttons (which also use
  // aria-label="Close") are never mistaken for Lowe's native control.
  function isCloseButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;
    if (!button.closest(".chatHeader")) return false;

    const label = normalizeText(
      button.getAttribute("aria-label") ||
      button.getAttribute("title") ||
      button.textContent
    ).toLowerCase();

    return label === "close" || label === "close chat";
  }

  function headerButtonLabels() {
    const header = getHeader();
    if (!header) return [];
    return [...header.querySelectorAll("button")].map(button => normalizeText(
      button.getAttribute("aria-label") ||
      button.getAttribute("title") ||
      button.textContent
    ).toLowerCase());
  }

  function headerHasCloseButton() {
    return headerButtonLabels().some(label => label === "close" || label === "close chat");
  }

  function headerHasEndChatButton() {
    return headerButtonLabels().some(label => label === "end chat");
  }

  // ===== End Chat -> native Close -> Pulse Tracker state machine =====
  // Strict lifecycle (Requirement 7 / 22/ 23):
  //   END_REQUESTED     agent clicked native "End Chat" (observation only)
  //   -> cancelled by agent  => state cleared, no Pulse, chat stays active
  //   -> CLOSE_AVAILABLE     Lowe's swapped the header control to "Close"
  //   CLOSE_AVAILABLE -> CLOSE_CLICKED   agent clicked the native Close button
  //   CLOSE_CLICKED -> CHAT_CLOSED       Lowe's actually removed the chat
  //   CHAT_CLOSED -> Pulse Tracker shown exactly once
  const END_STATE_TIMEOUT_MS = 30000;

  function captureEndChatIntent(button) {
    const header = getHeader();
    if (!header) return;

    const identity = getCurrentChatIdentity();
    if (!identity) return;

    if (agentEndState?.chatIdentity === identity && agentEndState.phase !== "CHAT_CLOSED_BY_AGENT") {
      return;
    }

    agentEndState = {
      chatIdentity: identity,
      chatRoot: header,
      initiatedAt: Date.now(),
      phase: "END_REQUESTED"
    };

    // This is observation only. Lowe's receives the original click unchanged.
  }

  function captureNativeCloseClick() {
    if (!agentEndState || agentEndState.phase !== "CLOSE_AVAILABLE") return;

    const identity = getCurrentChatIdentity();
    if (identity && agentEndState.chatIdentity && identity !== agentEndState.chatIdentity) return;

    agentEndState.phase = "CLOSE_CLICKED";
    agentEndState.closeClickedAt = Date.now();

    // Observation only. Lowe's receives the original click unchanged.
  }

  function chatIsActuallyClosed(state) {
    if (!state) return false;

    const currentHeader = getHeader();
    if (!currentHeader) return true;

    // If Lowe's rendered a different chat, the previous chat is closed.
    const currentIdentity = getCurrentChatIdentity();
    if (state.chatIdentity && currentIdentity && currentIdentity !== state.chatIdentity) {
      return true;
    }

    // Same header node can be retained by React while clearing its contents.
    if (state.chatRoot && !document.documentElement.contains(state.chatRoot)) return true;

    const name = normalizeText(currentHeader.querySelector(".name")?.textContent);
    const sub = normalizeText(currentHeader.querySelector(".sub")?.textContent);
    return !name && !sub;
  }

  function pollAgentEndState() {
    if (!agentEndState) return;

    // A stalled/ignored/cancelled native flow must not leave a stale
    // agent-intent hanging around indefinitely.
    if (Date.now() - agentEndState.initiatedAt > END_STATE_TIMEOUT_MS) {
      agentEndState = null;
      return;
    }

    if (agentEndState.phase === "END_REQUESTED") {
      const currentIdentity = getCurrentChatIdentity();
      const sameChatStillOpen = !!currentIdentity && currentIdentity === agentEndState.chatIdentity;

      if (headerHasCloseButton()) {
        // Requirement 7 Step 3: native Close control appeared.
        agentEndState.phase = "CLOSE_AVAILABLE";
        return;
      }

      if (sameChatStillOpen && headerHasEndChatButton()) {
        // The agent cancelled Lowe's native confirmation and the header
        // reverted to "End Chat". Requirement 7: do nothing, no Pulse.
        agentEndState = null;
        return;
      }

      if (!sameChatStillOpen && chatIsActuallyClosed(agentEndState)) {
        // The chat disappeared without ever exposing the native Close
        // control. Requirement 23: Pulse must never fire from End Chat
        // alone, so this is silently dropped rather than shown.
        agentEndState = null;
      }
      return;
    }

    if (agentEndState.phase === "CLOSE_AVAILABLE") {
      // Waiting for the agent to click the native Close button. If the
      // chat closes/changes before that click was ever observed, do not
      // show the Pulse Tracker (requirement 23).
      if (!headerHasCloseButton() && chatIsActuallyClosed(agentEndState)) {
        agentEndState = null;
      }
      return;
    }

    if (agentEndState.phase !== "CLOSE_CLICKED") return;

    // Requirement 7 Step 5: only after the native Close click AND Lowe's
    // actually removing/closing the chat does the Pulse Tracker appear.
    if (!chatIsActuallyClosed(agentEndState)) return;

    const finished = agentEndState;
    agentEndState = null;
    finished.phase = "CHAT_CLOSED_BY_AGENT";

    if (!addonSettings.pulseTracker) return;

    showEndChatPopup(finished.chatIdentity);
  }

  function showEndChatPopup(chatIdentity) {
    if (!addonSettings.pulseTracker) return;
    if (endChatPopup) return;
    if (!chatIdentity || handledAgentChats.has(`pulse:${chatIdentity}`)) return;

    // Requirement 9/12: exactly one Pulse Tracker per closed chat, tied to
    // this specific chat identity so re-renders/new chats never reuse it.
    handledAgentChats.add(`pulse:${chatIdentity}`);

    const overlay = document.createElement("div");
    overlay.id = "aux-end-chat-popup";
    overlay.dataset.chatIdentity = chatIdentity;

    overlay.innerHTML = `
      <div class="aux-end-chat-backdrop"></div>
      <div class="aux-end-chat-box" role="dialog" aria-modal="true" aria-labelledby="auxEndChatTitle">
        <button type="button" class="aux-end-chat-x" aria-label="Close">×</button>
        <div class="aux-end-chat-kicker">CHAT COMPLETE</div>
        <div class="aux-end-chat-title" id="auxEndChatTitle">How was the Chat?</div>
        <div class="aux-end-chat-sub">The chat has already been closed. Select the result to record your Pulse.</div>
        <div class="aux-end-chat-actions">
          <button type="button" class="aux-sat-btn aux-good">Good</button>
          <button type="button" class="aux-sat-btn aux-notsure">Not Sure</button>
          <button type="button" class="aux-sat-btn aux-bad">Bad</button>
        </div>
      </div>
    `;

    document.documentElement.appendChild(overlay);
    endChatPopup = overlay;

    let recorded = false;

    const remove = () => {
      if (overlay.isConnected) overlay.remove();
      if (endChatPopup === overlay) endChatPopup = null;
    };

    const finish = async result => {
      if (recorded) return;
      recorded = true;

      // Requirement 8/10: Good => ASAT+1, Bad => DSAT+1, Not Sure => no
      // metric changes and nothing is stored.
      if (result === "good" || result === "bad") {
        await updatePulse(result);
      }

      remove();
    };

    overlay.querySelector(".aux-good")?.addEventListener("click", () => finish("good"));
    overlay.querySelector(".aux-notsure")?.addEventListener("click", () => finish("notsure"));
    overlay.querySelector(".aux-bad")?.addEventListener("click", () => finish("bad"));
    overlay.querySelector(".aux-end-chat-x")?.addEventListener("click", remove);
    overlay.querySelector(".aux-end-chat-backdrop")?.addEventListener("click", remove);
  }

  function checkAcceptConfirmation() {
    // The native click must be allowed to finish first. Confirmation is
    // entirely state-based: a real active chat must appear.
    confirmAcceptedChat();
  }

  function handleNativeClickObservation(event) {
    const target = event.target;
    if (!target) return;

    // Never treat clicks inside the extension's own overlays as Lowe's
    // native page interactions.
    if (target.closest?.("#aux-chat-alert, #aux-end-chat-popup")) return;

    // Independent of tracking state: agent name -> extension's own page.
    if (isAgentNameTarget(target)) {
      openIndexPageInNewTab();
    }

    if (!isTargetTab) return;

    if (isAcceptButton(target)) {
      observeAcceptClick(target.closest("button"));
    }

    if (isEndChatButton(target)) {
      captureEndChatIntent(target.closest("button"));
    }

    if (isCloseButton(target)) {
      captureNativeCloseClick(target.closest("button"));
    }
  }

  // Capture phase is observation only. It does not cancel or alter the click.
  document.addEventListener("click", handleNativeClickObservation, true);

  function startAppObserver() {
    if (appObserver) return;

    appObserver = new MutationObserver(() => {
      scanChatQueue();
      checkAcceptConfirmation();
      pollAgentEndState();
    });

    appObserver.observe(document.documentElement || document, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: [
        "data-chat-id",
        "data-session-id",
        "data-request-id",
        "data-conversation-id",
        "data-interaction-id",
        "aria-label",
        "title",
        "class"
      ]
    });

    if (!queueScanTimer) {
      queueScanTimer = setInterval(() => {
        scanChatQueue();
        checkAcceptConfirmation();
        pollAgentEndState();
      }, 1000);
    }
  }

  function stopAppObserver() {
    if (queueScanTimer) clearInterval(queueScanTimer);
    queueScanTimer = null;

    if (appObserver) appObserver.disconnect();
    appObserver = null;

    for (const entry of queueEntries.values()) clearQueueEntryTimer(entry);
    queueEntries.clear();

    pendingAccepts.clear();
    agentEndState = null;
    removeChatWaitingPopup();
    endChatPopup?.remove();
    endChatPopup = null;
  }

  function applyAddonSettings(next) {
    const previous = addonSettings;
    addonSettings = { ...DEFAULT_ADDONS, ...(next || {}) };

    if (!addonSettings.chatAlerts) {
      // Requirement: turning alerts off removes timers and the visible popup.
      for (const entry of queueEntries.values()) clearQueueEntryTimer(entry);
      queueEntries.clear();
      removeChatWaitingPopup();
    } else if (
      !previous.chatAlerts ||
      Number(previous.chatInterval) !== Number(addonSettings.chatInterval)
    ) {
      // Do not reset waiting age. Re-schedule from firstSeenAt.
      for (const entry of queueEntries.values()) {
        if (!entry.alerted) scheduleQueueAlert(entry);
      }
    }

    if (!addonSettings.pulseTracker) {
      // Never show a Pulse popup while disabled.
      endChatPopup?.remove();
      endChatPopup = null;
    }

    if (isTargetTab) {
      startAppObserver();
      if (addonSettings.chatAlerts) scanChatQueue();
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[ADDON_KEY]) return;
    applyAddonSettings(changes[ADDON_KEY].newValue || {});
  });

  let targetStateTimer = null;

  function syncTargetState() {
    chrome.runtime.sendMessage({ type: "IS_TARGET_TAB" }).then(res => {
      const next = !!res?.isTargetTab;
      if (next === isTargetTab) return;
      isTargetTab = next;
      if (isTargetTab) {
        startAppObserver();
        if (addonSettings.chatAlerts) scanChatQueue();
      } else {
        stopAppObserver();
      }
    }).catch(() => {});
  }

  async function initializeAddon() {
    await loadAddonSettings();

    // Ask the service worker whether THIS tab is currently selected.
    // There is deliberately no URL/path check.
    syncTargetState();

    // Recover automatically after SPA navigation, frame replacement, or
    // service-worker/content-script timing races. This does not touch the
    // host page and only refreshes the extension's own target flag.
    if (!targetStateTimer) {
      targetStateTimer = setInterval(syncTargetState, 1500);
    }
  }

  initializeAddon();
}
