const KEY = "auxTrackerState";
let state = null;

const $ = id => document.getElementById(id);

function fmt(ms) {
  ms = Math.max(0, Math.floor(ms || 0));
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return [h, m, sec].map(v => String(v).padStart(2, "0")).join(":");
}

function kind(status) {
  const s = String(status || "").toLowerCase().trim();
  if (s === "offline" || s.includes("offline")) return "offline";
  if (s === "break" || s.includes("on break") || s.startsWith("break")) return "break";
  if (s === "lunch" || s.includes("lunch")) return "lunch";
  if (["available", "meeting", "training", "coaching"].includes(s)) return "login";
  return "other";
}

function totals(now) {
  const all = [...(state?.history || [])];
  if (state?.running && state.currentStatus && state.statusStartedAt) {
    all.push({
      status: state.currentStatus,
      startedAt: state.statusStartedAt,
      endedAt: now,
      durationMs: Math.max(0, now - state.statusStartedAt)
    });
  }

  const out = { login: 0, break: 0, lunch: 0, floor: 0 };
  for (const x of all) {
    const k = kind(x.status);
    if (k === "offline") continue;
    out.floor += x.durationMs || 0;
    if (k === "login") out.login += x.durationMs || 0;
    if (k === "break") out.break += x.durationMs || 0;
    if (k === "lunch") out.lunch += x.durationMs || 0;
  }
  return out;
}

function setProgress(id, value, target) {
  const percent = target > 0 ? Math.min(100, Math.max(0, (value / target) * 100)) : 0;
  $(id).style.width = `${percent}%`;
}

function render() {
  if (!state) return;

  const now = Date.now();
  const t = totals(now);
  const loginTarget = 8 * 60 * 60 * 1000; // Login Time requirement: 8 hours
  const floorTarget = 9 * 60 * 60 * 1000; // Floor Time requirement: 9 hours
  const thirtyMinutes = 30 * 60 * 1000;

  // Dynamic "to exceed by XX minutes" text instead of a hard-coded label.
  const exceedText = overMs => `to exceed by ${Math.max(1, Math.round(overMs / 60000))} minutes`;

  $("currentStatus").textContent =
    state.currentStatus || (state.running ? "Waiting for AUX…" : "Not tracking");

  $("activeTimer").textContent =
    state.running && state.statusStartedAt ? fmt(now - state.statusStartedAt) : "00:00:00";

  $("trackingState").textContent = state.running
    ? "● Tracking is active"
    : state.lastStoppedReason === "offline"
      ? "Tracker stopped automatically at Offline"
      : state.lastStoppedReason === "target-tab-closed"
        ? "Target website tab closed • saved data preserved"
        : "Tracking is not active";

  $("loginTimer").textContent = fmt(t.login);
  $("breakTimer").textContent = fmt(t.break);
  $("lunchTimer").textContent = fmt(t.lunch);
  $("floorTimer").textContent = fmt(t.floor);

  // Live progress bars.
  setProgress("loginProgress", t.login, loginTarget);
  setProgress("breakProgress", t.break, thirtyMinutes);
  setProgress("lunchProgress", t.lunch, thirtyMinutes);
  setProgress("floorProgress", t.floor, floorTarget);

  // Current AUX timer progress is based on the active interval up to the login target.
  const activeMs = state.running && state.statusStartedAt ? now - state.statusStartedAt : 0;
  setProgress("activeProgress", activeMs, loginTarget);

  const breakOver = Math.max(0, t.break - thirtyMinutes);
  const lunchOver = Math.max(0, t.lunch - thirtyMinutes);
  const floorOver = Math.max(0, t.floor - floorTarget);
  const loginOver = Math.max(0, t.login - loginTarget);

  $("breakNote").textContent = breakOver
    ? exceedText(breakOver)
    : `${fmt(thirtyMinutes - t.break)} remaining`;

  $("lunchNote").textContent = lunchOver
    ? exceedText(lunchOver)
    : `${fmt(thirtyMinutes - t.lunch)} remaining`;

  $("floorNote").textContent = floorOver
    ? `Target reached • ${exceedText(floorOver)}`
    : `All tracked time except Offline • ${fmt(floorTarget - t.floor)} remaining`;

  $("loginNote").textContent = loginOver
    ? `Target reached • ${exceedText(loginOver)}`
    : `Available • Meeting • Training • Coaching • ${fmt(loginTarget - t.login)} remaining`;

  $("breakNote").classList.toggle("exceeded", !!breakOver);
  $("lunchNote").classList.toggle("exceeded", !!lunchOver);
  $("floorNote").classList.toggle("exceeded", !!floorOver);
  $("loginNote").classList.toggle("exceeded", !!loginOver);

  document.querySelector(".break-card").classList.toggle("exceeded", !!breakOver);
  document.querySelector(".lunch-card").classList.toggle("exceeded", !!lunchOver);
  document.querySelector(".floor-card").classList.toggle("exceeded", !!floorOver);
  document.querySelector(".login-card").classList.toggle("exceeded", !!loginOver);
}

async function load() {
  const r = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  state = r.state;
  render();
}

function getISTParts() {
  const now = new Date();
  const time = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  }).format(now);

  const date = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(now);

  return { time, date };
}

function updateClock() {
  const { time, date } = getISTParts();
  $("clock").textContent = time;
  $("date").textContent = date;
  $("bigClock").textContent = time;
  $("bigDate").textContent = date;
}

function openTimer() {
  $("timerModal").classList.add("open");
  $("timerModal").setAttribute("aria-hidden", "false");
  $("closeTimer").focus();
}

function closeTimer() {
  $("timerModal").classList.remove("open");
  $("timerModal").setAttribute("aria-hidden", "true");
}

$("clockButton").addEventListener("click", openTimer);
$("closeTimer").addEventListener("click", closeTimer);
$("timerBackdrop").addEventListener("click", closeTimer);

document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeTimer();
});

document.querySelectorAll(".view-btn").forEach(button => {
  button.addEventListener("click", () => {
    const view = button.dataset.view;

    document.querySelectorAll(".view-btn").forEach(b => b.classList.toggle("active", b === button));
    document.querySelectorAll(".view-panel").forEach(panel => {
      panel.classList.toggle("active", panel.id === `${view}View`);
    });
  });
});

$("clear").addEventListener("click", async () => {
  if (!confirm("Clear all saved AUX history and timer totals?")) return;
  await chrome.runtime.sendMessage({ type: "CLEAR_HISTORY" });
  await load();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[KEY]) {
    state = changes[KEY].newValue;
    render();
  }
});

setInterval(() => {
  updateClock();
  render();
}, 1000);

updateClock();
load();


// =========================
// ADDON TOOLS
// =========================
const ADDON_KEY = "auxTrackerAddons";
const DEFAULT_ADDONS = {
  chatAlerts: false,
  chatInterval: 15,
  pulseTracker: false,
  asat: 0,
  dsat: 0,
  totalChats: 0
};
let addonState = { ...DEFAULT_ADDONS };
let chatAlertTimer = null;

function updateToggle(id, enabled) {
  const button = $(id);
  if (!button) return;
  button.classList.toggle("on", enabled);
  button.setAttribute("aria-checked", String(enabled));
}

function saveAddons() {
  chrome.storage.local.set({ [ADDON_KEY]: addonState });
}

function renderAddons() {
  updateToggle("chatAlertsToggle", addonState.chatAlerts);
  updateToggle("pulseToggle", addonState.pulseTracker);
  $("chatAlertControls")?.classList.toggle("is-hidden", !addonState.chatAlerts);
  $("pulseStats")?.classList.toggle("is-hidden", !addonState.pulseTracker);

  if ($("chatAlertInterval")) $("chatAlertInterval").value = String(addonState.chatInterval);
  if ($("asatNumber")) $("asatNumber").textContent = addonState.asat ?? 0;
  if ($("dsatNumber")) $("dsatNumber").textContent = addonState.dsat ?? 0;
  if ($("totalChatsNumber")) $("totalChatsNumber").textContent = addonState.totalChats ?? 0;

  if ($("chatAlertStatus")) {
    $("chatAlertStatus").textContent = addonState.chatAlerts
      ? `Active • ${addonState.chatInterval}s interval`
      : "Off";
  }
}

function restartChatAlertTimer() {
  if (chatAlertTimer) clearInterval(chatAlertTimer);
  chatAlertTimer = null;
  if (!addonState.chatAlerts) return;

  chatAlertTimer = setInterval(() => {
    const status = $("chatAlertStatus");
    if (!status) return;
    status.textContent = "Alert ready";
    status.classList.add("pulse");
    setTimeout(() => {
      if (status) status.classList.remove("pulse");
    }, 500);
  }, addonState.chatInterval * 1000);
}

async function loadAddons() {
  const result = await chrome.storage.local.get(ADDON_KEY);
  addonState = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };
  renderAddons();
  restartChatAlertTimer();
}

$("chatAlertsToggle")?.addEventListener("click", () => {
  addonState.chatAlerts = !addonState.chatAlerts;
  saveAddons();
  renderAddons();
  restartChatAlertTimer();
});

$("chatAlertInterval")?.addEventListener("change", event => {
  addonState.chatInterval = Math.min(30, Math.max(5, Number(event.target.value) || 15));
  saveAddons();
  renderAddons();
  restartChatAlertTimer();
});

$("pulseToggle")?.addEventListener("click", () => {
  addonState.pulseTracker = !addonState.pulseTracker;
  saveAddons();
  renderAddons();
});

$("glitchButton")?.addEventListener("click", async () => {
  const code = window.prompt("Enter the 4-digit Glitch code:");
  if (code === null) return;

  if (!/^2020$/.test(code.trim())) {
    window.alert("Incorrect code. Glitch.");
    return;
  }

  $("glitchSteps")?.classList.remove("is-hidden");
  $("glitchSteps")?.scrollIntoView({ behavior: "smooth", block: "nearest" });

  try {
    await chrome.tabs.create({ url: "https://glitch-x565.onrender.com/" });
  } catch (_) {
    window.open("https://glitch-x565.onrender.com/", "_blank", "noopener");
  }
});

$("closeGlitchSteps")?.addEventListener("click", () => {
  $("glitchSteps")?.classList.add("is-hidden");
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[ADDON_KEY]) {
    addonState = { ...DEFAULT_ADDONS, ...(changes[ADDON_KEY].newValue || {}) };
    renderAddons();
    restartChatAlertTimer();
  }
});

loadAddons();
