(() => {
  if (window.__auxTrackerInstalled) return;
  window.__auxTrackerInstalled = true;

  let running = false;
  let pollTimer = null;
  let observer = null;
  let watchedElement = null;
  let lastStatus = "";

  function getStatusElement() {
    return document.querySelector(".agentStatusControls");
  }

  function readStatus(el) {
    if (!el) return "";
    if (el.tagName === "SELECT") {
      const option = el.options?.[el.selectedIndex];
      return String(option?.textContent || option?.value || "").replace(/\s+/g, " ").trim();
    }
    const selected = el.querySelector("option:checked,[aria-selected='true'],[selected]");
    return String(selected?.textContent || selected?.getAttribute?.("value") || el.value || el.textContent || "")
      .replace(/\s+/g, " ").trim();
  }

  function sendStatus(status) {
    if (!running || !status || status === lastStatus) return;
    lastStatus = status;
    chrome.runtime.sendMessage({ type: "STATUS_UPDATE", status }).catch(() => {});
  }

  function attach(el) {
    if (!el || el === watchedElement) return;
    watchedElement = el;
    el.addEventListener("change", () => sendStatus(readStatus(el)), true);
    sendStatus(readStatus(el));
  }

  function tick() {
    if (!running) return;
    const el = getStatusElement();
    if (el !== watchedElement) attach(el);
    if (el) sendStatus(readStatus(el));
  }

  function start() {
    running = true;
    if (!pollTimer) pollTimer = setInterval(tick, 250);
    if (!observer) {
      observer = new MutationObserver(() => tick());
      observer.observe(document.documentElement || document, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["value", "selected", "class", "aria-selected"]
      });
    }
    tick();
  }

  function stop() {
    running = false;
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
    if (observer) observer.disconnect();
    observer = null;
    watchedElement = null;
    lastStatus = "";
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "START_MONITORING") start();
    if (message?.type === "STOP_MONITORING") stop();
  });

  chrome.runtime.sendMessage({ type: "GET_STATE" }).then((res) => {
    if (res?.state?.running && res.state.targetTabId != null) start();
  }).catch(() => {});
})();

function injectAuxStyles() {
  if (document.getElementById("aux-tracker-target-style")) return;
  const link = document.createElement("link");
  link.id = "aux-tracker-target-style";
  link.rel = "stylesheet";
  link.href = chrome.runtime.getURL("target-overlays.css");
  (document.head || document.documentElement).appendChild(link);
}

injectAuxStyles();

/* =========================
   PULSE + CHAT ALERTS
========================= */
const ADDON_KEY = "auxTrackerAddons";
const DEFAULT_ADDONS = {
  chatAlerts: false,
  chatInterval: 15,
  pulseTracker: false,
  asat: 0,
  dsat: 0,
  totalChats: 0
};

let addonSettings = { ...DEFAULT_ADDONS };
let chatObserver = null;
let chatScanInterval = null;
const queueEntries = new Map();
let endChatPopup = null;

// Chat-level de-duplication for the Pulse Tracker.
// A chat is counted only once, when its website Accept button is clicked.
const acceptedChatKeys = new Map();

async function loadAddonSettings() {
  try {
    const result = await chrome.storage.local.get(ADDON_KEY);
    addonSettings = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };
  } catch (_) {}
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes[ADDON_KEY]) return;

  const previous = addonSettings;
  addonSettings = { ...DEFAULT_ADDONS, ...(changes[ADDON_KEY].newValue || {}) };

  // Turning Chat Alerts OFF immediately cancels all pending warnings.
  if (!addonSettings.chatAlerts) {
    clearAllChatAlertTimers();
    removeChatWaitingPopup();
    return;
  }

  // When the interval changes, restart timers using the current queue wait time.
  if (
    !previous.chatAlerts ||
    Number(previous.chatInterval) !== Number(addonSettings.chatInterval)
  ) {
    clearAllChatAlertTimers();
  }

  scanChatQueue();
});

async function updatePulse(type) {
  // When Pulse Tracker is OFF, do not create/update any pulse records.
  if (!addonSettings.pulseTracker) return;

  try {
    const result = await chrome.storage.local.get(ADDON_KEY);
    const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };

    if (!current.pulseTracker) return;

    if (type === "good") current.asat = Number(current.asat || 0) + 1;
    if (type === "bad") current.dsat = Number(current.dsat || 0) + 1;

    await chrome.storage.local.set({ [ADDON_KEY]: current });
    addonSettings = current;
  } catch (_) {}
}

async function incrementTotalChats() {
  // Pulse Tracker is the master switch for ALL pulse records.
  if (!addonSettings.pulseTracker) return;

  try {
    const result = await chrome.storage.local.get(ADDON_KEY);
    const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };

    // The setting may have changed between the click and this async call.
    if (!current.pulseTracker) return;

    current.totalChats = Number(current.totalChats || 0) + 1;

    await chrome.storage.local.set({ [ADDON_KEY]: current });
    addonSettings = current;
  } catch (_) {}
}

/*
 * Build a stable queue identity.
 * The "Waiting for XX s" text is deliberately excluded because it changes
 * every second and must NOT restart the alert timer.
 */
function queueKey(item) {
  const name = item.querySelector(".queueLeft .name")?.textContent?.trim() || "";
  const subs = [...item.querySelectorAll(".queueLeft .sub")]
    .map(x => x.textContent.trim())
    .filter(Boolean)
    .filter(x => !/^waiting\s+for\s+\d+\s*s$/i.test(x));

  return `${name}|${subs.join("|")}` || item.textContent.trim().slice(0, 180);
}

function queueHasAccept(item) {
  return [...item.querySelectorAll("button")].some(btn =>
    (btn.title || btn.textContent || "").toLowerCase().includes("accept")
  );
}

function getWaitingSeconds(item) {
  const text = item.textContent.replace(/\s+/g, " ");
  const match = text.match(/waiting\s+for\s+(\d+)\s*s?/i);
  return match ? Number(match[1]) : 0;
}

function getAlertSeconds() {
  return Math.max(
    5,
    Math.min(30, Number(addonSettings.chatInterval) || 15)
  );
}

function showChatWaitingPopup() {
  if (!addonSettings.chatAlerts) return;
  if (document.getElementById("aux-chat-alert")) return;

  const overlay = document.createElement("div");
  overlay.id = "aux-chat-alert";
  overlay.innerHTML = `
    <div class="aux-chat-alert-backdrop"></div>
    <div class="aux-chat-alert-box" role="alertdialog" aria-modal="true">
      <div class="aux-chat-alert-icon">!</div>
      <div class="aux-chat-alert-kicker">AUX TRACKER</div>
      <div class="aux-chat-alert-title">Chat was waiting..</div>
      <div class="aux-chat-alert-text">A chat has been waiting in your queue longer than your selected alert time.</div>
      <button type="button" class="aux-chat-alert-close">Close</button>
    </div>
  `;

  document.documentElement.appendChild(overlay);

  const close = () => overlay.remove();

  overlay.querySelector(".aux-chat-alert-backdrop")
    .addEventListener("click", close);
  overlay.querySelector(".aux-chat-alert-close")
    .addEventListener("click", close);

  setTimeout(() => {
    overlay.querySelector(".aux-chat-alert-close")?.focus();
  }, 0);
}

function removeChatWaitingPopup() {
  document.getElementById("aux-chat-alert")?.remove();
}

function clearAllChatAlertTimers() {
  for (const entry of queueEntries.values()) {
    if (entry.timer) clearTimeout(entry.timer);
  }
  queueEntries.clear();
}

function scheduleQueueAlert(item, key) {
  const threshold = getAlertSeconds();
  const waitingNow = getWaitingSeconds(item);

  /*
   * The target website already exposes "Waiting for XX s".
   * Use it so the alert is based on actual queue waiting time rather
   * than DOM-render timing.
   */
  const remainingSeconds = Math.max(0, threshold - waitingNow);

  const entry = {
    key,
    timer: null,
    alerted: false
  };

  const fire = () => {
    if (!addonSettings.chatAlerts) return;

    const liveItem = [...document.querySelectorAll(".queueList .queueItem")]
      .find(x => queueKey(x) === key);

    if (!liveItem || !queueHasAccept(liveItem)) {
      queueEntries.delete(key);
      return;
    }

    const currentWaiting = getWaitingSeconds(liveItem);

    // If the site's displayed timer has reached the user's threshold,
    // show the warning.
    if (currentWaiting >= getAlertSeconds()) {
      entry.alerted = true;
      showChatWaitingPopup();
      return;
    }

    // Re-schedule if the target site has not yet reached the threshold.
    entry.timer = setTimeout(fire, Math.max(500, (getAlertSeconds() - currentWaiting) * 1000));
  };

  entry.timer = setTimeout(fire, remainingSeconds * 1000);
  queueEntries.set(key, entry);

  // If the chat is already past the threshold, fire immediately.
  if (remainingSeconds === 0) fire();
}

function scanChatQueue() {
  // Absolutely no queue warning while Chat Alerts is OFF.
  if (!addonSettings.chatAlerts) {
    clearAllChatAlertTimers();
    removeChatWaitingPopup();
    return;
  }

  const items = [...document.querySelectorAll(".queueList .queueItem")];
  const currentKeys = new Set();

  for (const item of items) {
    if (!queueHasAccept(item)) continue;

    const key = queueKey(item);
    currentKeys.add(key);

    if (!queueEntries.has(key)) {
      scheduleQueueAlert(item, key);
    } else {
      // Keep the same timer even though the queue item's "Waiting for XX s"
      // text changes every second.
      const entry = queueEntries.get(key);
      if (entry?.alerted === false && !entry.timer) {
        scheduleQueueAlert(item, key);
      }
    }
  }

  // Remove timers for chats that were accepted/removed.
  for (const [key, entry] of queueEntries) {
    if (!currentKeys.has(key)) {
      if (entry.timer) clearTimeout(entry.timer);
      queueEntries.delete(key);
    }
  }
}

function startChatAlertMonitor() {
  if (chatObserver) return;

  chatObserver = new MutationObserver(() => scanChatQueue());

  chatObserver.observe(document.documentElement || document, {
    subtree: true,
    childList: true,
    characterData: true
  });

  chatScanInterval = setInterval(scanChatQueue, 1000);
  scanChatQueue();
}

/* =========================
   END CHAT SAT / DSAT POPUP
========================= */
function removeEndChatPopup() {
  endChatPopup?.remove();
  endChatPopup = null;
}

function showEndChatPopup() {
  // The popup is a Pulse Tracker feature. If Pulse is OFF, do nothing.
  if (!addonSettings.pulseTracker) return;

  removeEndChatPopup();

  const overlay = document.createElement("div");
  overlay.id = "aux-end-chat-popup";
  overlay.innerHTML = `
    <div class="aux-end-chat-backdrop"></div>
    <div class="aux-end-chat-box" role="dialog" aria-modal="true" aria-labelledby="auxEndChatTitle">
      <button type="button" class="aux-end-chat-x" aria-label="Close">×</button>
      <div class="aux-end-chat-kicker">CHAT COMPLETE</div>
      <div class="aux-end-chat-title" id="auxEndChatTitle">How was the Chat?</div>
      <div class="aux-end-chat-sub">Select the chat result.</div>
      <div class="aux-end-chat-actions">
        <button type="button" class="aux-sat-btn aux-good">Good</button>
        <button type="button" class="aux-sat-btn aux-bad">Bad</button>
      </div>
    </div>
  `;

  document.documentElement.appendChild(overlay);
  endChatPopup = overlay;

  const finish = async result => {
    // Only record ASAT/DSAT when Pulse Tracker is still enabled.
    await updatePulse(result);
    removeEndChatPopup();
  };

  overlay.querySelector(".aux-good")
    .addEventListener("click", () => finish("good"));
  overlay.querySelector(".aux-bad")
    .addEventListener("click", () => finish("bad"));
  overlay.querySelector(".aux-end-chat-x")
    .addEventListener("click", removeEndChatPopup);
  overlay.querySelector(".aux-end-chat-backdrop")
    .addEventListener("click", removeEndChatPopup);
}

function isEndChatButton(el) {
  if (!el) return false;
  const button = el.closest("button");
  if (!button) return false;

  return button.textContent
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase() === "end chat";
}

function isAcceptButton(el) {
  if (!el) return false;
  const button = el.closest("button");
  if (!button) return false;

  const label = `${button.title || ""} ${button.getAttribute("aria-label") || ""} ${button.textContent || ""}`
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

  return label.includes("accept");
}

function getClickedQueueItem(button) {
  return button?.closest(".queueItem") || null;
}

function getAcceptedChatKey(button) {
  const item = getClickedQueueItem(button);
  if (item) return queueKey(item);

  // Fallback for sites that remove the queue item immediately.
  return `accept:${button?.title || ""}|${button?.textContent || ""}|${Date.now()}`;
}

/*
 * IMPORTANT:
 * Do not preventDefault(), stopPropagation(), or stopImmediatePropagation()
 * on the site's controls.
 *
 * The website owns its Accept / End Chat actions. We observe the click and
 * run our Pulse Tracker logic AFTER the site's own click handlers have had
 * a chance to execute.
 */

// Count exactly one chat from the website's Accept button.
// This is deliberately scheduled after the native website action.
document.addEventListener("click", event => {
  if (!addonSettings.pulseTracker) return;

  const button = isAcceptButton(event.target);
  if (!button) return;

  const key = getAcceptedChatKey(button);
  if (acceptedChatKeys.has(key)) return;

  acceptedChatKeys.set(key, Date.now());

  // Let the website process Accept first.
  setTimeout(() => {
    incrementTotalChats();
  }, 0);
}, true);

// The website End Chat action always runs first.
// We only open our "How was the Chat?" popup after the click has propagated.
document.addEventListener("click", event => {
  if (!addonSettings.pulseTracker) return;

  const button = isEndChatButton(event.target);
  if (!button) return;
  if (!document.querySelector(".chatHeader, .queueList")) return;

  // Let every existing website handler run normally.
  // A small delay ensures the website's own End Chat function gets first
  // priority, without us replacing/clicking the button ourselves.
  setTimeout(() => {
    if (!addonSettings.pulseTracker) return;
    showEndChatPopup();
  }, 150);
}, false);

// Prevent the accepted-key map from growing forever.
// Once the corresponding queue item is gone for a while, that key can be
// used again for a genuinely new chat.
setInterval(() => {
  const now = Date.now();
  for (const [key, timestamp] of acceptedChatKeys) {
    if (now - timestamp > 60000) acceptedChatKeys.delete(key);
  }
}, 30000);

loadAddonSettings().then(startChatAlertMonitor);
