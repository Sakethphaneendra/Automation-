const $ = (id) => document.getElementById(id);

let state = null;

async function getState() {

  const r = await chrome.runtime.sendMessage({type:"GET_STATE"});

  state = r.state;

  render();

}

function render() {

  const running = !!state?.running;

  $("toggle").classList.toggle("running", running);

  $("toggleText").textContent = running ? "STOP" : "START";

  $("helper").textContent = running ? "Tracking is active" : "Ready to monitor AUX";

  $("reason").textContent = state?.lastStoppedReason === "offline" ? "Automatically stopped: Offline" :

    state?.lastStoppedReason === "target-tab-closed" ? "Target tab closed — data saved" : "";

}

$("toggle").addEventListener("click", async () => {

  if (state?.running) {

    await chrome.runtime.sendMessage({type:"STOP_TRACKING"});

  } else {

    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});

    if (!tab?.id) return;

    const r = await chrome.runtime.sendMessage({type:"START_TRACKING",tabId:tab.id});

    if (r?.ok) {

      setTimeout(() => chrome.runtime.sendMessage({type:"OPEN_DASHBOARD"}), 2000);

    }

  }

  await getState();

});

$("saketh").addEventListener("click", () => {

  chrome.tabs.create({url:"about:blank"});

});

function updateClock() {

  const now = new Date();

  $("clock").textContent = new Intl.DateTimeFormat("en-IN", {

    timeZone:"Asia/Kolkata", hour:"2-digit", minute:"2-digit", second:"2-digit", hour12:false

  }).format(now);

  $("date").textContent = new Intl.DateTimeFormat("en-IN", {

    timeZone:"Asia/Kolkata", weekday:"short", day:"2-digit", month:"short", year:"numeric"

  }).format(now);

}

chrome.storage.onChanged.addListener((changes, area) => {

  if (area === "local" && changes.auxTrackerState) getState();

});

updateClock(); setInterval(updateClock, 1000); getState();  