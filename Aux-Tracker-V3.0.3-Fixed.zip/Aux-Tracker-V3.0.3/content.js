(() => {
  if (window.__auxTrackerInstalled) return;
  window.__auxTrackerInstalled = true;

  let running = false;
  let pollTimer = null;
  let statusObserver = null;
  let watchedElement = null;
  let lastStatus = "";

  function getStatusElement() {
    return document.querySelector(".agentStatusControls");
  }

  function readStatus(el) {
    if (!el) return "";
    if (el.tagName === "SELECT") {
      const option = el.options?.[el.selectedIndex];
      return String(option?.textContent || option?.value || "").replace(/\s+/g, " ").trim();
    }
    const selected = el.querySelector("option:checked,[aria-selected='true'],[selected]");
    return String(selected?.textContent || selected?.getAttribute?.("value") || el.value || el.textContent || "")
      .replace(/\s+/g, " ").trim();
  }

  function sendStatus(status) {
    if (!running || !status || status === lastStatus) return;
    lastStatus = status;
    chrome.runtime.sendMessage({ type: "STATUS_UPDATE", status }).catch(() => {});
  }

  function attach(el) {
    if (!el || el === watchedElement) return;
    watchedElement = el;
    el.addEventListener("change", () => sendStatus(readStatus(el)), true);
    sendStatus(readStatus(el));
  }

  function tick() {
    if (!running) return;
    const el = getStatusElement();
    if (el !== watchedElement) attach(el);
    if (el) sendStatus(readStatus(el));
  }

  function start() {
    if (running) {
      tick();
      return;
    }

    running = true;
    if (!pollTimer) pollTimer = setInterval(tick, 250);

    if (!statusObserver) {
      statusObserver = new MutationObserver(() => tick());
      statusObserver.observe(document.documentElement || document, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["value", "selected", "class", "aria-selected"]
      });
    }

    tick();
  }

  function stop() {
    running = false;
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
    if (statusObserver) statusObserver.disconnect();
    statusObserver = null;
    watchedElement = null;
    lastStatus = "";
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "START_MONITORING") start();
    if (message?.type === "STOP_MONITORING") stop();
  });

  chrome.runtime.sendMessage({ type: "GET_STATE" }).then((res) => {
    if (res?.state?.running && res.state.targetTabId != null) start();
  }).catch(() => {});
})();

function normalizeText(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

/* =========================
   AUX ADD-ON OBSERVERS
   =========================
   This section is intentionally passive:
   - no preventDefault()
   - no stopPropagation()
   - no stopImmediatePropagation()
   - no replacement of Lowe's buttons/functions
   - no modification of Lowe's application state
*/
function injectAuxStyles() {
  if (document.getElementById("aux-tracker-target-style")) return;
  const link = document.createElement("link");
  link.id = "aux-tracker-target-style";
  link.rel = "stylesheet";
  link.href = chrome.runtime.getURL("target-overlays.css");
  (document.head || document.documentElement).appendChild(link);
}

injectAuxStyles();

{
  // Run the webpage add-on layer in every frame. Lowe's can render
  // parts of the chat/queue UI inside an iframe; restricting this layer
  // to window.top makes those parts invisible to the extension.
  const ADDON_KEY = "auxTrackerAddons";
  const DEFAULT_ADDONS = {
    chatAlerts: false,
    chatInterval: 15,
    pulseTracker: false,
    asat: 0,
    dsat: 0,
    totalChats: 0
  };

  // No Lowe's URL/path allow-list is used. The extension is scoped to
  // the tab selected when tracking is started. SPA navigation in that tab
  // remains part of the same tracking session.
  let isTargetTab = false;

  // Single monitor state. These are intentionally created once per page.
  let addonSettings = { ...DEFAULT_ADDONS };
  const queueEntries = new Map();
  const pendingAccepts = new Map();
  const handledAgentChats = new Set();
  let agentEndState = null;
  let endChatPopup = null;
  let appObserver = null;
  let queueScanTimer = null;
  const QUEUE_ABSENCE_GRACE_MS = 4000;

  // The background service worker tells this tab when it becomes the target.
  // This listener only changes AUX internal state; it never touches Lowe's events.
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "TARGET_TAB_STATE") {
      const next = !!message.isTargetTab;
      if (next === isTargetTab) return;
      isTargetTab = next;
      if (isTargetTab) {
        startAppObserver();
        if (addonSettings.chatAlerts) scanChatQueue();
      } else {
        stopAppObserver();
      }
    }
  });

  function requestTargetTabState() {
    chrome.runtime.sendMessage({ type: "IS_TARGET_TAB" }).then(res => {
      const next = !!res?.isTargetTab;
      if (next === isTargetTab) return;
      isTargetTab = next;
      if (isTargetTab) {
        startAppObserver();
        if (addonSettings.chatAlerts) scanChatQueue();
      } else {
        stopAppObserver();
      }
    }).catch(() => {});
  }

  function getAlertSeconds() {
    return Math.max(5, Math.min(30, Number(addonSettings.chatInterval) || 15));
  }

  function readAttributeIdentity(root) {
    if (!root) return "";

    const attrs = [
      "data-chat-id",
      "data-session-id",
      "data-request-id",
      "data-conversation-id",
      "data-interaction-id",
      "data-customer-id",
      "data-contact-id",
      "data-chatid",
      "data-sessionid",
      "data-requestid",
      "data-conversationid",
      "data-interactionid"
    ];

    const nodes = [root, ...root.querySelectorAll("*")];
    for (const node of nodes) {
      for (const attr of attrs) {
        const value = normalizeText(node.getAttribute?.(attr));
        if (value) return `${attr}:${value}`;
      }
    }

    return "";
  }

  function getHeader() {
    return document.querySelector(".chatHeader");
  }

  function getCurrentChatIdentity() {
    const header = getHeader();
    if (!header) return "";

    const strongId = readAttributeIdentity(header);
    if (strongId) return strongId;

    const name = normalizeText(header.querySelector(".name")?.textContent);
    const sub = normalizeText(header.querySelector(".sub")?.textContent);

    // Fallback only when Lowe's exposes no obvious stable identifier.
    return [name, sub].filter(Boolean).join("|");
  }

  function getQueueIdentity(item) {
    if (!item) return "";

    const strongId = readAttributeIdentity(item);
    if (strongId) return strongId;

    const values = [];

    const name = normalizeText(item.querySelector(".queueLeft .name")?.textContent);
    if (name) values.push(`name:${name}`);

    for (const sub of item.querySelectorAll(".queueLeft .sub")) {
      const text = normalizeText(sub.textContent);
      if (!text) continue;
      if (/^waiting\s+for\s+\d+\s*s?$/i.test(text)) continue;
      values.push(`sub:${text}`);
    }

    // Never use the changing "Waiting for XX s" text as identity.
    return values.join("|") || "";
  }

  function getWaitingSeconds(item) {
    const text = normalizeText(item?.textContent);
    const match = text.match(/waiting\s+for\s+(\d+)\s*s?/i);
    return match ? Number(match[1]) : 0;
  }

  function queueHasAccept(item) {
    return [...item.querySelectorAll("button")].some(button => {
      const label = normalizeText(
        button.getAttribute("aria-label") ||
        button.getAttribute("title") ||
        button.textContent
      ).toLowerCase();

      return label === "accept" || label.includes("accept");
    });
  }

  function findQueueItemByIdentity(key) {
    return [...document.querySelectorAll(".queueList .queueItem")]
      .find(item => getQueueIdentity(item) === key) || null;
  }

  function clearQueueEntryTimer(entry) {
    if (entry?.timer) {
      clearTimeout(entry.timer);
      entry.timer = null;
    }
  }

  function removeChatWaitingPopup() {
    document.getElementById("aux-chat-alert")?.remove();
  }

  function showChatWaitingPopup() {
    if (!isTargetTab || !addonSettings.chatAlerts) return;
    if (document.getElementById("aux-chat-alert")) return;

    const overlay = document.createElement("div");
    overlay.id = "aux-chat-alert";

    overlay.innerHTML = `
      <div class="aux-chat-alert-backdrop"></div>
      <div class="aux-chat-alert-box" role="alertdialog" aria-modal="true">
        <div class="aux-chat-alert-icon">!</div>
        <div class="aux-chat-alert-kicker">AUX TRACKER</div>
        <div class="aux-chat-alert-title">Chat was waiting..</div>
        <div class="aux-chat-alert-text">A chat has been waiting in your queue longer than your selected alert time.</div>
        <button type="button" class="aux-chat-alert-close">Close</button>
      </div>
    `;

    document.documentElement.appendChild(overlay);

    const close = () => overlay.remove();
    overlay.querySelector(".aux-chat-alert-backdrop")?.addEventListener("click", close);
    overlay.querySelector(".aux-chat-alert-close")?.addEventListener("click", close);
  }

  function scheduleQueueAlert(entry) {
    clearQueueEntryTimer(entry);

    if (!addonSettings.chatAlerts) return;
    if (entry.alerted) return;

    const thresholdMs = getAlertSeconds() * 1000;
    const dueAt = entry.firstSeenAt + thresholdMs;
    const remaining = Math.max(0, dueAt - Date.now());

    const fire = () => {
      entry.timer = null;

      if (!addonSettings.chatAlerts || entry.alerted) return;
      const item = findQueueItemByIdentity(entry.key);
      if (!item || !queueHasAccept(item)) {
        // Keep the stable entry alive across transient SPA renders/navigation.
        entry.lastSeenAt = Date.now();
        return;
      }

      const currentWaiting = getWaitingSeconds(item);
      const elapsed = Date.now() - entry.firstSeenAt;

      if (currentWaiting >= getAlertSeconds() || elapsed >= thresholdMs) {
        entry.alerted = true;
        entry.alertedAt = Date.now();
        showChatWaitingPopup();
        return;
      }

      scheduleQueueAlert(entry);
    };

    entry.timer = setTimeout(fire, Math.max(50, remaining));
  }

  function ensureQueueEntry(item, key) {
    const now = Date.now();
    const waitingSeconds = getWaitingSeconds(item);
    let entry = queueEntries.get(key);

    if (!entry) {
      entry = {
        key,
        firstSeenAt: now - Math.max(0, waitingSeconds) * 1000,
        lastSeenAt: now,
        alerted: false,
        alertedAt: null,
        timer: null
      };
      queueEntries.set(key, entry);
      scheduleQueueAlert(entry);
      return entry;
    }

    entry.lastSeenAt = now;

    // If the threshold setting changes while this same chat is waiting,
    // recalculate from the original waiting start instead of restarting it.
    if (!entry.alerted && !entry.timer) {
      scheduleQueueAlert(entry);
    }

    return entry;
  }

  function pruneQueueEntries() {
    const now = Date.now();
    for (const [key, entry] of queueEntries) {
      if (now - (entry.lastSeenAt || now) > QUEUE_ABSENCE_GRACE_MS) {
        clearQueueEntryTimer(entry);
        queueEntries.delete(key);
      }
    }
  }

  function scanChatQueue() {
    if (!isTargetTab || !addonSettings.chatAlerts) return;

    const items = [...document.querySelectorAll(".queueList .queueItem")];

    for (const item of items) {
      if (!queueHasAccept(item)) continue;

      const key = getQueueIdentity(item);
      if (!key) continue;

      ensureQueueEntry(item, key);
    }

    pruneQueueEntries();
  }

  async function loadAddonSettings() {
    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      addonSettings = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };
    } catch (_) {}
  }

  async function updatePulse(type) {
    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };

      if (type === "good") current.asat = Number(current.asat || 0) + 1;
      if (type === "bad") current.dsat = Number(current.dsat || 0) + 1;

      await chrome.storage.local.set({ [ADDON_KEY]: current });
      addonSettings = current;
    } catch (_) {}
  }

  async function incrementTotalChatsOnce(identity) {
    if (!identity) return false;
    if (handledAgentChats.has(identity)) return false;

    handledAgentChats.add(identity);

    try {
      const result = await chrome.storage.local.get(ADDON_KEY);
      const current = { ...DEFAULT_ADDONS, ...(result[ADDON_KEY] || {}) };
      current.totalChats = Number(current.totalChats || 0) + 1;
      await chrome.storage.local.set({ [ADDON_KEY]: current });
      addonSettings = current;
      return true;
    } catch (_) {
      handledAgentChats.delete(identity);
      return false;
    }
  }

  function cleanupPendingAccepts() {
    const now = Date.now();
    for (const [id, pending] of pendingAccepts) {
      if (now - pending.clickedAt > 15000) pendingAccepts.delete(id);
    }
  }

  function findPendingAcceptForChat(identity) {
    if (!identity) return null;

    for (const [id, pending] of pendingAccepts) {
      if (pending.expectedIdentity && pending.expectedIdentity === identity) {
        return [id, pending];
      }
    }

    // If Lowe's did not expose a usable ID, only a newly-opened/different
    // chat can confirm the observed Accept click.
    for (const [id, pending] of pendingAccepts) {
      if (pending.previousChatIdentity && pending.previousChatIdentity === identity) continue;
      if (Date.now() - pending.clickedAt <= 10000) return [id, pending];
    }

    return null;
  }

  function confirmAcceptedChat() {
    cleanupPendingAccepts();

    const identity = getCurrentChatIdentity();
    if (!identity) return;

    // If the same chat was already open before Accept was clicked, that is
    // not confirmation of a newly accepted queue chat.
    for (const pending of pendingAccepts.values()) {
      if (pending.previousChatIdentity && pending.previousChatIdentity === identity) {
        pending.lastCheckedIdentity = identity;
      }
    }

    const match = findPendingAcceptForChat(identity);
    if (!match) return;

    const [pendingId, pending] = match;
    pendingAccepts.delete(pendingId);

    // Only the successful open-chat confirmation can increment Total Chats.
    incrementTotalChatsOnce(identity);
  }

  function observeAcceptClick(button) {
    const queueItem = button.closest(".queueItem");
    const queueIdentity = queueItem ? getQueueIdentity(queueItem) : "";

    const pendingId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    pendingAccepts.set(pendingId, {
      clickedAt: Date.now(),
      queueIdentity,
      previousChatIdentity: getCurrentChatIdentity(),
      expectedIdentity: "",
      confirmed: false
    });

    // Do not touch the native event. No preventDefault/stopPropagation calls.
  }

  function isAcceptButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;

    const label = normalizeText(
      button.getAttribute("aria-label") ||
      button.getAttribute("title") ||
      button.textContent
    ).toLowerCase();

    return label === "accept" || label.includes("accept");
  }

  function isEndChatButton(target) {
    const button = target?.closest?.("button");
    if (!button) return false;

    return normalizeText(
      button.getAttribute("aria-label") ||
      button.getAttribute("title") ||
      button.textContent
    ).toLowerCase() === "end chat";
  }

  function captureEndChatIntent(button) {
    const header = getHeader();
    if (!header) return;

    const identity = getCurrentChatIdentity();
    if (!identity) return;

    // If an end request is already waiting for this same chat, do nothing.
    if (agentEndState?.chatIdentity === identity &&
        agentEndState.phase === "WAITING_FOR_CHAT_CLOSE") {
      return;
    }

    agentEndState = {
      chatIdentity: identity,
      chatRoot: header,
      initiatedAt: Date.now(),
      phase: "AGENT_END_INITIATED"
    };

    // This is observation only. Lowe's receives the original click unchanged.
  }

  function chatIsActuallyClosed(state) {
    if (!state) return false;

    const currentHeader = getHeader();
    if (!currentHeader) return true;

    // If Lowe's rendered a different chat, the previous chat is closed.
    const currentIdentity = getCurrentChatIdentity();
    if (state.chatIdentity && currentIdentity && currentIdentity !== state.chatIdentity) {
      return true;
    }

    // Same header node can be retained by React while clearing its contents.
    if (state.chatRoot && !document.documentElement.contains(state.chatRoot)) return true;

    const name = normalizeText(currentHeader.querySelector(".name")?.textContent);
    const sub = normalizeText(currentHeader.querySelector(".sub")?.textContent);
    return !name && !sub;
  }

  function pollAgentEndState() {
    if (!agentEndState) return;

    // A failed/ignored native End Chat action must not leave a stale
    // agent-intent that could incorrectly classify a later customer close.
    if (Date.now() - agentEndState.initiatedAt > 15000) {
      agentEndState = null;
      return;
    }

    if (agentEndState.phase === "AGENT_END_INITIATED") {
      agentEndState.phase = "WAITING_FOR_CHAT_CLOSE";
    }

    if (agentEndState.phase !== "WAITING_FOR_CHAT_CLOSE") return;

    if (!chatIsActuallyClosed(agentEndState)) return;

    const finished = agentEndState;
    agentEndState = null;
    finished.phase = "CHAT_CLOSED_BY_AGENT";

    if (!addonSettings.pulseTracker) return;

    // The native Lowe's chat is already closed before this overlay exists.
    showEndChatPopup(finished.chatIdentity);
  }

  function showEndChatPopup(chatIdentity) {
    if (!addonSettings.pulseTracker) return;
    if (endChatPopup) return;
    if (!chatIdentity || handledAgentChats.has(`pulse:${chatIdentity}`)) return;

    handledAgentChats.add(`pulse:${chatIdentity}`);

    const overlay = document.createElement("div");
    overlay.id = "aux-end-chat-popup";
    overlay.dataset.chatIdentity = chatIdentity;

    overlay.innerHTML = `
      <div class="aux-end-chat-backdrop"></div>
      <div class="aux-end-chat-box" role="dialog" aria-modal="true" aria-labelledby="auxEndChatTitle">
        <button type="button" class="aux-end-chat-x" aria-label="Close">×</button>
        <div class="aux-end-chat-kicker">CHAT COMPLETE</div>
        <div class="aux-end-chat-title" id="auxEndChatTitle">How was the Chat?</div>
        <div class="aux-end-chat-sub">The chat has already been ended. Select the result to record your Pulse.</div>
        <div class="aux-end-chat-actions">
          <button type="button" class="aux-sat-btn aux-good">Good</button>
          <button type="button" class="aux-sat-btn aux-bad">Bad</button>
        </div>
      </div>
    `;

    document.documentElement.appendChild(overlay);
    endChatPopup = overlay;

    let recorded = false;

    const remove = () => {
      if (overlay.isConnected) overlay.remove();
      if (endChatPopup === overlay) endChatPopup = null;
    };

    const finish = async result => {
      if (recorded) return;
      recorded = true;
      await updatePulse(result);
      remove();
    };

    overlay.querySelector(".aux-good")?.addEventListener("click", () => finish("good"));
    overlay.querySelector(".aux-bad")?.addEventListener("click", () => finish("bad"));
    overlay.querySelector(".aux-end-chat-x")?.addEventListener("click", remove);
    overlay.querySelector(".aux-end-chat-backdrop")?.addEventListener("click", remove);
  }

  function checkAcceptConfirmation() {
    // The native click must be allowed to finish first. Confirmation is
    // entirely state-based: a real active chat must appear.
    confirmAcceptedChat();
  }

  function handleNativeClickObservation(event) {
    if (!isTargetTab) return;
    const target = event.target;
    if (!target) return;

    if (isAcceptButton(target)) {
      observeAcceptClick(target.closest("button"));
    }

    if (isEndChatButton(target)) {
      captureEndChatIntent(target.closest("button"));
    }
  }

  // Capture phase is observation only. It does not cancel or alter the click.
  document.addEventListener("click", handleNativeClickObservation, true);

  function startAppObserver() {
    if (appObserver) return;

    appObserver = new MutationObserver(() => {
      scanChatQueue();
      checkAcceptConfirmation();
      pollAgentEndState();
    });

    appObserver.observe(document.documentElement || document, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: [
        "data-chat-id",
        "data-session-id",
        "data-request-id",
        "data-conversation-id",
        "data-interaction-id",
        "aria-label",
        "title",
        "class"
      ]
    });

    if (!queueScanTimer) {
      queueScanTimer = setInterval(() => {
        scanChatQueue();
        checkAcceptConfirmation();
        pollAgentEndState();
      }, 1000);
    }
  }

  function stopAppObserver() {
    if (queueScanTimer) clearInterval(queueScanTimer);
    queueScanTimer = null;

    if (appObserver) appObserver.disconnect();
    appObserver = null;

    for (const entry of queueEntries.values()) clearQueueEntryTimer(entry);
    queueEntries.clear();

    pendingAccepts.clear();
    agentEndState = null;
    removeChatWaitingPopup();
    endChatPopup?.remove();
    endChatPopup = null;
  }

  function applyAddonSettings(next) {
    const previous = addonSettings;
    addonSettings = { ...DEFAULT_ADDONS, ...(next || {}) };

    if (!addonSettings.chatAlerts) {
      // Requirement: turning alerts off removes timers and the visible popup.
      for (const entry of queueEntries.values()) clearQueueEntryTimer(entry);
      queueEntries.clear();
      removeChatWaitingPopup();
    } else if (
      !previous.chatAlerts ||
      Number(previous.chatInterval) !== Number(addonSettings.chatInterval)
    ) {
      // Do not reset waiting age. Re-schedule from firstSeenAt.
      for (const entry of queueEntries.values()) {
        if (!entry.alerted) scheduleQueueAlert(entry);
      }
    }

    if (!addonSettings.pulseTracker) {
      // Never show a Pulse popup while disabled.
      endChatPopup?.remove();
      endChatPopup = null;
    }

    if (isTargetTab) {
      startAppObserver();
      if (addonSettings.chatAlerts) scanChatQueue();
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[ADDON_KEY]) return;
    applyAddonSettings(changes[ADDON_KEY].newValue || {});
  });

  let targetStateTimer = null;

  function syncTargetState() {
    chrome.runtime.sendMessage({ type: "IS_TARGET_TAB" }).then(res => {
      const next = !!res?.isTargetTab;
      if (next === isTargetTab) return;
      isTargetTab = next;
      if (isTargetTab) {
        startAppObserver();
        if (addonSettings.chatAlerts) scanChatQueue();
      } else {
        stopAppObserver();
      }
    }).catch(() => {});
  }

  async function initializeAddon() {
    await loadAddonSettings();

    // Ask the service worker whether THIS tab is currently selected.
    // There is deliberately no URL/path check.
    syncTargetState();

    // Recover automatically after SPA navigation, frame replacement, or
    // service-worker/content-script timing races. This does not touch the
    // host page and only refreshes the extension's own target flag.
    if (!targetStateTimer) {
      targetStateTimer = setInterval(syncTargetState, 1500);
    }
  }

  initializeAddon();
}
