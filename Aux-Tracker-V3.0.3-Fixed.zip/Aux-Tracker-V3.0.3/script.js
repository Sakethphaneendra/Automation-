function copyEmail() {
  const email = "sakethphaneendra@gmail.com";

  navigator.clipboard.writeText(email).then(() => {
    const toast = document.getElementById("toast");
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 1600);
  });
}
